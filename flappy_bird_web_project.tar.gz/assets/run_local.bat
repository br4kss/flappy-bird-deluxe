@echo off
setlocal
cd /d "%~dp0"
if not exist "build\web\index.html" (
  echo ERREUR : build\web\index.html introuvable.
  echo Lance d'abord build_web.bat et attends la fin de la compilation.
  pause
  exit /b 1
)
echo Demarrage du serveur local pour Flappy Bird Deluxe Ultimate...
echo Quand le navigateur s'ouvre, attends quelques secondes.
echo Pour arreter le serveur, ferme cette fenetre.
start "" "http://127.0.0.1:8000/"
python -m http.server 8000 --directory "build\web"
pause
