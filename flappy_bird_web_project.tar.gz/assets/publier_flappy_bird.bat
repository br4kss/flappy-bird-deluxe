@echo off
set "PATH=C:\Program Files\Git\cmd;C:\Program Files\Git\bin;%PATH%"
set "GIT_PATH=C:\Program Files\Git\cmd\git.exe"
setlocal EnableExtensions
title Publier Flappy Bird Deluxe sur GitHub Pages

REM Place ce fichier dans le meme dossier que build_web.bat et ton projet.
REM Il publie le contenu de build\web a la racine du depot GitHub.
set "PROJECT_DIR=%~dp0"
set "REPO_URL=https://github.com/br4kss/flappy-bird-deluxe.git"
set "WORK_DIR=%TEMP%\flappy-bird-deluxe-publish"

echo.
echo ============================================
echo   Publication de Flappy Bird Deluxe
echo ============================================
echo.

where git >nul 2>nul
if errorlevel 1 (
    echo ERREUR : Git n'est pas installe ou n'est pas dans le PATH.
    echo Installe Git for Windows depuis https://git-scm.com/download/win
    echo puis relance ce fichier.
    pause
    exit /b 1
)

if not exist "%PROJECT_DIR%build_web.bat" (
    echo ERREUR : build_web.bat est introuvable.
    echo Place ce fichier .bat dans le dossier de ton projet, a cote de build_web.bat.
    pause
    exit /b 1
)

pushd "%PROJECT_DIR%"

echo [1/4] Construction de la version web...
call "%PROJECT_DIR%build_web.bat"
if errorlevel 1 (
    echo.
    echo ERREUR : la construction web a echoue. Rien n'a ete publie.
    popd
    pause
    exit /b 1
)

if not exist "%PROJECT_DIR%build\web\index.html" (
    echo.
    echo ERREUR : build\web\index.html est introuvable.
    echo Verifie que build_web.bat genere bien le dossier build\web.
    popd
    pause
    exit /b 1
)

echo.
echo [2/4] Recuperation du depot GitHub...
if exist "%WORK_DIR%" rmdir /s /q "%WORK_DIR%"
git clone --branch main "%REPO_URL%" "%WORK_DIR%"
if errorlevel 1 (
    echo.
    echo ERREUR : impossible de cloner le depot.
    echo Verifie ta connexion et que tu as acces au depot GitHub.
    echo Pour envoyer des modifications, Git doit etre authentifie sur ton compte.
    popd
    pause
    exit /b 1
)

echo.
echo [3/4] Copie des fichiers web publies...
REM Supprime les anciens fichiers du site, mais conserve .git et README.md.
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "Get-ChildItem -LiteralPath '%WORK_DIR%' -Force | Where-Object { $_.Name -ne '.git' -and $_.Name -ne 'README.md' } | Remove-Item -Recurse -Force"
if errorlevel 1 (
    echo ERREUR : impossible de nettoyer le dossier temporaire.
    popd
    pause
    exit /b 1
)

robocopy "%PROJECT_DIR%build\web" "%WORK_DIR%" /E /R:2 /W:1
if errorlevel 8 (
    echo ERREUR : la copie des fichiers web a echoue.
    popd
    pause
    exit /b 1
)

pushd "%WORK_DIR%"
git add -A
git diff --cached --quiet
if not errorlevel 1 (
    echo.
    echo Aucun changement detecte : le site est deja a jour.
    popd
    popd
    echo.
    echo Adresse du jeu : https://br4kss.github.io/flappy-bird-deluxe/
    pause
    exit /b 0
)

git commit -m "Update web game"
if errorlevel 1 (
    echo.
    echo ERREUR : le commit a echoue.
    echo Verifie la configuration de ton nom et de ton e-mail Git.
    popd
    popd
    pause
    exit /b 1
)

echo.
echo [4/4] Envoi vers GitHub...
git push origin main
if errorlevel 1 (
    echo.
    echo ERREUR : l'envoi vers GitHub a echoue.
    echo Si Git demande une connexion, connecte-toi avec le navigateur ou Git Credential Manager,
    echo puis relance ce fichier.
    popd
    popd
    pause
    exit /b 1
)

popd
popd
echo.
echo ============================================
echo Publication envoyee a GitHub !
echo GitHub Pages peut prendre quelques minutes.
echo Adresse : https://br4kss.github.io/flappy-bird-deluxe/
echo Sur iPhone, ferme puis rouvre le jeu ou recharge la page.
echo ============================================
pause
exit /b 0
