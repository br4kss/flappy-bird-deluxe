from pathlib import Path
import re

root = Path(__file__).resolve().parent
web_dir = root / "build" / "web"
index = web_dir / "index.html"

if not index.exists():
    raise SystemExit(
        "ERREUR : build/web/index.html introuvable. "
        "Lance d'abord Pygbag depuis le dossier contenant main.py."
    )

html = index.read_text(encoding="utf-8")

# Remove our previous injected block before re-applying it.
html = re.sub(
    r'\s*<!-- FLAPPY RESPONSIVE START -->.*?<!-- FLAPPY RESPONSIVE END -->\s*',
    '\n',
    html,
    flags=re.DOTALL,
)

# Remove simple existing viewport tags so there is only one.
html = re.sub(r'<meta\s+name=["\']viewport["\'][^>]*>\s*', '', html, flags=re.I)

injection = r"""
<!-- FLAPPY RESPONSIVE START -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#10182f">
<style id="flappy-responsive-canvas">
  html, body {
    width: 100% !important;
    height: 100% !important;
    min-height: 100% !important;
    margin: 0 !important;
    padding: 0 !important;
    overflow: hidden !important;
    background: #10182f !important;
  }
  body {
    display: flex !important;
    justify-content: center !important;
    align-items: center !important;
    min-height: 100vh !important;
    min-height: 100dvh !important;
  }
  canvas {
    display: block !important;
    /* Logical game ratio is 520:700. Fit the full canvas into the screen. */
    width: min(100vw, 74.2857vh) !important;
    width: min(100vw, 74.2857dvh) !important;
    height: auto !important;
    max-width: 100vw !important;
    max-height: 100vh !important;
    max-height: 100dvh !important;
    aspect-ratio: 520 / 700 !important;
    object-fit: contain !important;
    margin: auto !important;
    touch-action: manipulation !important;
  }
  @media (orientation: landscape) {
    canvas {
      width: min(100vw, 74.2857vh) !important;
      width: min(100vw, 74.2857dvh) !important;
      max-height: 100vh !important;
      max-height: 100dvh !important;
    }
  }
</style>
<!-- FLAPPY RESPONSIVE END -->
"""

if re.search(r"</head\s*>", html, flags=re.I):
    html = re.sub(r"</head\s*>", injection + "\n</head>", html, count=1, flags=re.I)
else:
    html = injection + "\n" + html

index.write_text(html, encoding="utf-8")
print("OK : build/web/index.html adapte au format portrait et a la taille de l'ecran.")
