from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
WEB = ROOT / "build" / "web"
PWA = ROOT / "pwa"

if not WEB.is_dir():
    raise SystemExit("Dossier build/web introuvable. Lance d'abord la construction Pygbag.")

for name in ("manifest.webmanifest", "sw.js", "icon.svg"):
    shutil.copy2(PWA / name, WEB / name)

index = WEB / "index.html"
if not index.exists():
    raise SystemExit("index.html introuvable dans build/web.")

html = index.read_text(encoding="utf-8")

# Keep the game in its logical portrait ratio (520 x 700) and scale it to fit
# phone and tablet screens without stretching it.
head_injection = r"""
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover">
<meta name="theme-color" content="#10182f">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Flappy Deluxe">
<link rel="manifest" href="manifest.webmanifest">
<link rel="apple-touch-icon" href="icon.svg">
<style id="flappy-responsive-portrait">
  html, body {
    width: 100%;
    height: 100%;
    min-height: 100%;
    margin: 0 !important;
    padding: 0 !important;
    overflow: hidden !important;
    background: #10182f !important;
  }
  body {
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    min-height: 100vh;
    min-height: 100dvh;
  }
  canvas {
    display: block !important;
    width: min(100vw, 74.2857dvh) !important;
    height: min(100dvh, 134.6154vw) !important;
    max-width: 100vw !important;
    max-height: 100vh !important;
    max-height: 100dvh !important;
    aspect-ratio: 520 / 700;
    object-fit: contain;
    margin: auto !important;
    touch-action: none;
  }
  @supports not (height: 100dvh) {
    canvas {
      width: min(100vw, 74.2857vh) !important;
      height: min(100vh, 134.6154vw) !important;
    }
  }
</style>
<script>
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('./sw.js').catch(console.warn);
    });
  }
</script>
"""
# Replace any old responsive patch so repeated builds don't duplicate it.
start_tag = '<style id="flappy-responsive-portrait">'
if start_tag in html:
    start = html.index(start_tag)
    end = html.find("</style>", start)
    if end != -1:
        end += len("</style>")
        html = html[:start] + html[end:]

# Inject/update mobile viewport and PWA links once.
for marker in ('<meta name="viewport"', '<link rel="manifest"'):
    if marker in html:
        # Avoid duplicate viewport/manifest tags by removing existing simple lines.
        lines = html.splitlines()
        html = "\n".join(line for line in lines if marker not in line)

if "</head>" in html:
    html = html.replace("</head>", head_injection + "\n</head>", 1)
else:
    html = head_injection + html

index.write_text(html, encoding="utf-8")
print("Adaptation portrait responsive appliquée à build/web.")
