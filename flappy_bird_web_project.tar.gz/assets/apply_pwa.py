from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
WEB = ROOT / "build" / "web"
if not WEB.is_dir():
    raise SystemExit("Dossier build/web introuvable. Lance d'abord : python -m pygbag --build .")

for name in ("manifest.webmanifest", "sw.js", "icon.svg"):
    shutil.copy2(ROOT / "pwa" / name, WEB / name)

index = WEB / "index.html"
if not index.exists():
    raise SystemExit("index.html introuvable dans build/web. Vérifie la sortie de Pygbag.")
html = index.read_text(encoding="utf-8")
if "manifest.webmanifest" not in html:
    inject = """
<link rel="manifest" href="manifest.webmanifest">
<meta name="theme-color" content="#10182f">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Flappy Deluxe">
<link rel="apple-touch-icon" href="icon.svg">
<script>if ('serviceWorker' in navigator) { window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(console.warn)); }</script>
"""
    if "</head>" in html:
        html = html.replace("</head>", inject + "</head>", 1)
    else:
        html = inject + html
    index.write_text(html, encoding="utf-8")
print("PWA prêt : déploie le contenu de build/web/ sur un hébergement HTTPS.")
