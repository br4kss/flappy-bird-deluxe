import os
import sys
import json
import random
import time
import colorsys
import asyncio
from datetime import date, timedelta

import pygame

# ------------------------------------------------------------
# Flappy Bird Deluxe Ultimate - Pygame, fichier unique
# ------------------------------------------------------------
pygame.init()
WIDTH, HEIGHT = 520, 700
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Flappy Bird Deluxe Ultimate")
clock = pygame.time.Clock()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SAVE_FILE = os.path.join(BASE_DIR, "flappy_save.json")

WHITE = (250, 250, 255)
BLACK = (25, 25, 35)
GOLD = (255, 210, 55)
GREEN = (45, 190, 75)
DARK = (30, 35, 55)

BIRDS = {
    "Classique": (255, 220, 45),
    "Rouge": (240, 75, 75),
    "Bleu": (70, 155, 255),
    "Violet": (175, 90, 230),
    "Rose": (255, 125, 190),
    "Or": (255, 180, 35),
}
PIPES = {
    "Verts": (45, 190, 75),
    "Bleus": (55, 150, 235),
    "Rouges": (225, 65, 65),
    "Violets": (155, 75, 210),
    "Dorés": (235, 175, 35),
}
BACKGROUNDS = {
    "Ciel": (110, 195, 255),
    "Coucher de soleil": (245, 150, 115),
    "Nuit": (28, 35, 75),
    "Menthe": (145, 225, 195),
    "Lavande": (190, 175, 235),
}

# Les 6 skins classiques restent identiques. Les skins 7 à 100 ont un nouveau thème.
SKIN_PREFIXES = ["Nébuleuse", "Cyber", "Aurore", "Prisme", "Cosmique", "Tropical", "Volcan", "Cristal", "Fantôme", "Turbo"]
SKIN_FINISHES = ["rubis", "saphir", "émeraude", "améthyste", "ambre", "corail", "néon", "galaxie", "glacier", "arc-en-ciel"]
_skin_names = [f"{prefix} {finish}" for prefix in SKIN_PREFIXES for finish in SKIN_FINISHES]
for skin_index, skin_name in enumerate(_skin_names[:94], start=6):
    hue = ((skin_index - 6) / 94.0 + 0.037 * (skin_index % 5)) % 1.0
    saturation = 0.62 + (skin_index % 4) * 0.09
    brightness = 0.82 + (skin_index % 3) * 0.09
    rgb = colorsys.hsv_to_rgb(hue, min(0.98, saturation), min(1.0, brightness))
    BIRDS[skin_name] = tuple(round(channel * 255) for channel in rgb)
BIRDS["Custom"] = (255, 80, 190)

HATS = {
    "Aucun": {"style": "none", "color": (0, 0, 0)},
    "Couronne royale": {"style": "crown", "color": (255, 205, 35)},
    "Casquette rouge": {"style": "cap", "color": (235, 55, 65)},
    "Haut-de-forme": {"style": "tophat", "color": (35, 35, 50)},
    "Chapeau de sorcier": {"style": "wizard", "color": (110, 70, 205)},
    "Halo céleste": {"style": "halo", "color": (255, 245, 135)},
    "Bonnet d'hiver": {"style": "beanie", "color": (65, 175, 245)},
    "Pirate": {"style": "pirate", "color": (30, 30, 40)},
    "Sombrero fiesta": {"style": "sombrero", "color": (245, 145, 40)},
    "Oreilles de chat": {"style": "cat", "color": (255, 120, 190)},
    "Casque astronaute": {"style": "space", "color": (190, 220, 245)},
    "Couronne de glace": {"style": "crown", "color": (120, 235, 255)},
    "Fleur tropicale": {"style": "flower", "color": (255, 90, 150)},
    "Diadème étoilé": {"style": "crown", "color": (180, 140, 255)},
    "Casque gamer": {"style": "headphones", "color": (70, 240, 170)},
    "Chapeau champignon": {"style": "mushroom", "color": (230, 60, 70)},
    "Béret français": {"style": "beret", "color": (35, 45, 90)},
    "Cowboy": {"style": "cowboy", "color": (165, 100, 45)},
    "Couronne florale": {"style": "flower", "color": (255, 205, 75)},
    "Oreoles démoniaques": {"style": "horns", "color": (245, 65, 85)},
    "Chapeau disco": {"style": "tophat", "color": (70, 225, 235)},
    "Casque chevalier": {"style": "knight", "color": (155, 165, 185)},
    "Bonnet pastèque": {"style": "beanie", "color": (70, 190, 90)},
    "Auréole dorée": {"style": "halo", "color": (255, 200, 55)},
}

GLASSES = {
    "Aucune": {"style": "none", "color": (0, 0, 0)},
    "Lunettes pixel": {"style": "pixel", "color": (25, 25, 35)},
    "Aviator dorées": {"style": "aviator", "color": (255, 190, 55)},
    "Lunettes néon": {"style": "neon", "color": (65, 255, 210)},
    "Cœurs roses": {"style": "heart", "color": (255, 75, 155)},
    "Rondes rétro": {"style": "round", "color": (80, 55, 35)},
    "Visière cyber": {"style": "visor", "color": (80, 235, 255)},
    "Lunettes d'espion": {"style": "dark", "color": (20, 20, 30)},
    "Étoiles": {"style": "star", "color": (255, 220, 60)},
    "Monture violette": {"style": "round", "color": (165, 80, 240)},
    "Monture menthe": {"style": "pixel", "color": (95, 245, 175)},
    "Lunettes soleil": {"style": "dark", "color": (255, 130, 45)},
    "Lunettes 3D": {"style": "3d", "color": (255, 70, 90)},
    "Verres glacés": {"style": "aviator", "color": (115, 210, 255)},
    "Robo-vision": {"style": "visor", "color": (235, 80, 255)},
    "Lunettes rondes or": {"style": "round", "color": (255, 205, 65)},
    "Lunettes champion": {"style": "sport", "color": (80, 180, 255)},
    "Lunettes fantôme": {"style": "round", "color": (230, 240, 255)},
    "Lunettes camouflage": {"style": "pixel", "color": (80, 135, 65)},
    "Monocle chic": {"style": "monocle", "color": (255, 205, 65)},
}
TRAILS = {
    "Aucun": None,
    "Étincelles": (255, 220, 70),
    "Bulles": (95, 235, 245),
    "Flammes": (255, 100, 45),
    "Étoiles": (235, 235, 255),
}
TRAIL_PRICES = {
    "Étincelles": 140,
    "Bulles": 140,
    "Flammes": 220,
    "Étoiles": 220,
}

BOX_COST = 30
COINS_PER_PIPE = 1
COINS_PER_GAME = 3
MODE_3D_COST = 100
REVIVE_COST = 60
MAGNET_COST = 250

FONT = pygame.font.SysFont("Arial", 30, bold=True)
MEDIUM = pygame.font.SysFont("Arial", 22, bold=True)
SMALL = pygame.font.SysFont("Arial", 17)
TINY = pygame.font.SysFont("Arial", 14)

MISSIONS = [
    {"id": "first_flight", "title": "Premier vol", "description": "Termine 1 partie", "stat": "games", "target": 1, "reward": 25},
    {"id": "ten_pipes", "title": "As de l'air", "description": "Passe 10 tuyaux au total", "stat": "pipes", "target": 10, "reward": 40},
    {"id": "x2_finder", "title": "Chasseur de bonus", "description": "Ramasse 3 bulles x2", "stat": "x2_collected", "target": 3, "reward": 60},
    {"id": "coin_hunter", "title": "Collectionneur", "description": "Ramasse 5 pièces bonus", "stat": "coin_pickups", "target": 5, "reward": 50},
    {"id": "ace", "title": "Pilote confirmé", "description": "Atteins 10 points en une partie", "stat": "best_run", "target": 10, "reward": 100},
    {"id": "veteran", "title": "Vétéran", "description": "Termine 10 parties", "stat": "games", "target": 10, "reward": 100},
]


def default_save():
    return {
        "coins": 0,
        "best_scores": [],
        "unlocked_birds": ["Classique"],
        "unlocked_pipes": ["Verts"],
        "unlocked_backgrounds": ["Ciel"],
        "bird": "Classique",
        "custom_bird_rgb": [255, 80, 190],
        "custom_bird_hsv": [0.91, 0.69, 1.0],
        "pipe": "Verts",
        "background": "Ciel",
        "unlocked_modes": ["classic"],
        "revives": 0,
        "magnet": False,
        "unlocked_trails": ["Aucun"],
        "trail": "Aucun",
        "unlocked_hats": ["Aucun"],
        "hat": "Aucun",
        "unlocked_glasses": ["Aucune"],
        "glasses": "Aucune",
        "dev_mode": False,
        "shop_rotation_offers": [],
        "shop_rotation_at": 0.0,
        "last_daily_claim": "",
        "daily_streak": 0,
        "claimed_missions": [],
        "stats": {
            "games": 0,
            "pipes": 0,
            "x2_collected": 0,
            "coin_pickups": 0,
            "best_run": 0,
            "coins_earned": 0,
        },
    }


def load_save():
    base = default_save()
    # Safari/Pygbag : récupère la sauvegarde depuis le stockage local du navigateur.
    if sys.platform == "emscripten":
        try:
            import platform
            browser_storage = platform.window.localStorage
            browser_save = browser_storage.getItem("flappy_bird_deluxe_save")
            if browser_save:
                with open(SAVE_FILE, "w", encoding="utf-8") as file:
                    file.write(str(browser_save))
        except Exception:
            pass
    if not os.path.exists(SAVE_FILE):
        # Compatibilité avec le tout premier système de scores.
        old_scores = os.path.join(BASE_DIR, "scores.json")
        if os.path.exists(old_scores):
            try:
                with open(old_scores, "r", encoding="utf-8") as file:
                    data = json.load(file)
                if isinstance(data, list):
                    base["best_scores"] = sorted({int(x) for x in data if str(x).isdigit()}, reverse=True)[:10]
            except (OSError, json.JSONDecodeError, TypeError, ValueError):
                pass
        return base

    try:
        with open(SAVE_FILE, "r", encoding="utf-8") as file:
            loaded = json.load(file)
        if isinstance(loaded, dict):
            base.update(loaded)
    except (OSError, json.JSONDecodeError, TypeError):
        return base

    # Normalise les anciennes sauvegardes sans perdre leurs données.
    for key, choices, equipped_key in [
        ("unlocked_birds", BIRDS, "bird"),
        ("unlocked_pipes", PIPES, "pipe"),
        ("unlocked_backgrounds", BACKGROUNDS, "background"),
        ("unlocked_trails", TRAILS, "trail"),
        ("unlocked_hats", HATS, "hat"),
        ("unlocked_glasses", GLASSES, "glasses"),
    ]:
        if not isinstance(base.get(key), list):
            base[key] = [base.get(equipped_key, next(iter(choices)))]
        base[key] = [item for item in base[key] if item in choices]
        if base.get(equipped_key) not in choices:
            base[equipped_key] = next(iter(choices))
        if base[equipped_key] not in base[key]:
            base[key].append(base[equipped_key])

    for key, choices in [("bird", BIRDS), ("pipe", PIPES), ("background", BACKGROUNDS),
                         ("trail", TRAILS), ("hat", HATS), ("glasses", GLASSES)]:
        if base.get(key) not in choices:
            base[key] = next(iter(choices))

    if not isinstance(base.get("unlocked_modes"), list):
        base["unlocked_modes"] = ["classic"]
    if "classic" not in base["unlocked_modes"]:
        base["unlocked_modes"].append("classic")
    base["unlocked_modes"] = [mode for mode in base["unlocked_modes"] if mode in ("classic", "3d")]
    if not isinstance(base.get("best_scores"), list):
        base["best_scores"] = []
    try:
        base["best_scores"] = sorted({int(x) for x in base["best_scores"] if str(x).isdigit()}, reverse=True)[:10]
        base["coins"] = max(0, int(base.get("coins", 0)))
        base["revives"] = max(0, min(99, int(base.get("revives", 0))))
        base["daily_streak"] = max(0, int(base.get("daily_streak", 0)))
    except (ValueError, TypeError):
        base["coins"] = 0
        base["revives"] = 0
        base["daily_streak"] = 0
    base["magnet"] = bool(base.get("magnet", False))
    try:
        rgb = base.get("custom_bird_rgb", [255, 80, 190])
        if not isinstance(rgb, (list, tuple)) or len(rgb) != 3:
            raise ValueError
        base["custom_bird_rgb"] = [max(0, min(255, int(v))) for v in rgb]
        hsv = base.get("custom_bird_hsv", [0.91, 0.69, 1.0])
        if not isinstance(hsv, (list, tuple)) or len(hsv) != 3:
            raise ValueError
        base["custom_bird_hsv"] = [max(0.0, min(1.0, float(v))) for v in hsv]
    except (TypeError, ValueError):
        base["custom_bird_rgb"] = [255, 80, 190]
        base["custom_bird_hsv"] = [0.91, 0.69, 1.0]
    base["dev_mode"] = bool(base.get("dev_mode", False))
    if not isinstance(base.get("shop_rotation_offers"), list):
        base["shop_rotation_offers"] = []
    try:
        base["shop_rotation_at"] = float(base.get("shop_rotation_at", 0.0))
    except (TypeError, ValueError):
        base["shop_rotation_at"] = 0.0
    if not isinstance(base.get("claimed_missions"), list):
        base["claimed_missions"] = []
    old_stats = base.get("stats", {})
    if not isinstance(old_stats, dict):
        old_stats = {}
    stats_defaults = default_save()["stats"]
    stats_defaults.update({k: max(0, int(old_stats.get(k, 0))) for k in stats_defaults if str(old_stats.get(k, 0)).isdigit()})
    base["stats"] = stats_defaults
    return base


save_data = load_save()


def save_game():
    try:
        serialized = json.dumps(save_data, indent=2, ensure_ascii=False)
        with open(SAVE_FILE, "w", encoding="utf-8") as file:
            file.write(serialized)
        # Le stockage local permet de conserver pièces, skins et progression après fermeture de Safari.
        if sys.platform == "emscripten":
            try:
                import platform
                platform.window.localStorage.setItem("flappy_bird_deluxe_save", serialized)
            except Exception:
                pass
    except OSError:
        set_notice("Impossible d'écrire flappy_save.json !", 240)


def dev_mode_enabled():
    return bool(save_data.get("dev_mode", False))


def coins_label():
    return "∞ pièces" if dev_mode_enabled() else f"{save_data['coins']:,} pièces".replace(",", " ")


def can_afford(amount):
    return dev_mode_enabled() or save_data["coins"] >= int(amount)


def spend_coins(amount):
    """Débite les pièces normalement ; en mode dev, la monnaie est infinie."""
    if dev_mode_enabled():
        save_data["coins"] = 999999
        return True
    if save_data["coins"] < int(amount):
        return False
    save_data["coins"] -= int(amount)
    return True


def award_coins(amount):
    if amount <= 0:
        return
    if dev_mode_enabled():
        save_data["coins"] = 999999
    else:
        save_data["coins"] += int(amount)
    save_data["stats"]["coins_earned"] += int(amount)
    save_game()


def set_notice(message, frames=210):
    global notice, notice_timer
    notice = message
    notice_timer = frames


def add_score(score):
    # Score unique : une valeur n'apparaît qu'une fois dans le classement.
    score_set = set(save_data["best_scores"])
    score_set.add(int(score))
    save_data["best_scores"] = sorted(score_set, reverse=True)[:10]


def check_missions():
    # La progression se met à jour pendant la partie, mais aucune récompense
    # n'est versée automatiquement : il faut cliquer sur RÉCLAMER dans Missions.
    save_game()


def claim_mission(mission):
    if mission["id"] in save_data["claimed_missions"]:
        set_notice("Cette récompense a déjà été récupérée.")
        return
    if save_data["stats"].get(mission["stat"], 0) < mission["target"]:
        set_notice("Mission pas encore terminée.")
        return
    save_data["claimed_missions"].append(mission["id"])
    award_coins(mission["reward"])
    save_game()
    set_notice(f"Récompense récupérée : +{mission['reward']} pièces !", 220)


def save_finished_game(score):
    add_score(score)
    save_data["stats"]["games"] += 1
    save_data["stats"]["best_run"] = max(save_data["stats"]["best_run"], int(score))
    award_coins(COINS_PER_GAME)
    save_game()
    check_missions()


def bird_color(name):
    if name == "Custom":
        return tuple(save_data.get("custom_bird_rgb", [255, 80, 190]))
    return BIRDS.get(name, BIRDS["Classique"])


def update_custom_bird_color_from_hsv():
    hsv = save_data.get("custom_bird_hsv", [0.91, 0.69, 1.0])
    rgb = colorsys.hsv_to_rgb(*hsv)
    save_data["custom_bird_rgb"] = [max(0, min(255, round(v * 255))) for v in rgb]


def seconds_until_next_daily():
    now = time.time()
    tomorrow = date.today() + timedelta(days=1)
    next_midnight = time.mktime((tomorrow.year, tomorrow.month, tomorrow.day, 0, 0, 0, 0, 0, -1))
    return max(0, int(next_midnight - now))


def today_reward_preview():
    today = date.today()
    last = save_data.get("last_daily_claim", "")
    if last == today.isoformat():
        return 0, save_data.get("daily_streak", 0), True
    try:
        yesterday = (today - timedelta(days=1)).isoformat()
    except OverflowError:
        yesterday = ""
    streak = min(save_data.get("daily_streak", 0) + 1, 7) if last == yesterday else 1
    return min(20 + (streak - 1) * 5, 50), streak, False


def claim_daily_reward():
    reward, streak, already = today_reward_preview()
    if already:
        set_notice("Récompense quotidienne déjà récupérée !")
        return
    save_data["last_daily_claim"] = date.today().isoformat()
    save_data["daily_streak"] = streak
    award_coins(reward)
    set_notice(f"Récompense quotidienne : +{reward} pièces ! Série : {streak} jour(s).", 260)


def buy_mode_3d():
    if "3d" in save_data["unlocked_modes"]:
        return True
    if not can_afford(MODE_3D_COST):
        set_notice(f"Il te faut {MODE_3D_COST} pièces pour débloquer le mode 3D.")
        return False
    spend_coins(MODE_3D_COST)
    save_data["unlocked_modes"].append("3d")
    save_game()
    set_notice("Mode 3D débloqué ! Clique encore sur le bouton pour jouer.")
    return True


def buy_lootbox():
    if not can_afford(BOX_COST):
        set_notice(f"Pas assez de pièces : la lootbox coûte {BOX_COST}.")
        return
    categories = [
        ("bird", BIRDS, "unlocked_birds", "oiseau"),
        ("pipe", PIPES, "unlocked_pipes", "tuyau"),
        ("background", BACKGROUNDS, "unlocked_backgrounds", "fond"),
        ("hat", HATS, "unlocked_hats", "chapeau"),
        ("glasses", GLASSES, "unlocked_glasses", "lunettes"),
    ]
    possible = []
    for equip_key, choices, unlocked_key, category_name in categories:
        for item in choices:
            if item not in save_data[unlocked_key]:
                possible.append((equip_key, item, unlocked_key, category_name))
    if not possible:
        set_notice("Tous les skins classiques sont déjà débloqués ! Essaie la boutique.")
        return
    spend_coins(BOX_COST)
    equip_key, item, unlocked_key, category_name = random.choice(possible)
    save_data[unlocked_key].append(item)
    save_data[equip_key] = item
    save_game()
    set_notice(f"Lootbox : {item} ({category_name}) débloqué et équipé !", 260)


def shop_items():
    return [
        {"id": "mode3d", "label": "Débloquer le MODE 3D", "price": MODE_3D_COST},
        {"id": "revive", "label": f"Jeton de sauvetage (stock : {save_data['revives']})", "price": REVIVE_COST},
        {"id": "magnet", "label": "Aimant à pièces permanent", "price": MAGNET_COST},
        {"id": "trail_spark", "label": "Trail Étincelles", "price": TRAIL_PRICES["Étincelles"], "trail": "Étincelles"},
        {"id": "trail_bubble", "label": "Trail Bulles", "price": TRAIL_PRICES["Bulles"], "trail": "Bulles"},
        {"id": "trail_fire", "label": "Trail Flammes", "price": TRAIL_PRICES["Flammes"], "trail": "Flammes"},
        {"id": "trail_star", "label": "Trail Étoiles", "price": TRAIL_PRICES["Étoiles"], "trail": "Étoiles"},
    ]


def shop_item_status(item):
    item_id = item["id"]
    if item_id == "mode3d":
        return "DÉBLOQUÉ" if "3d" in save_data["unlocked_modes"] else f"{item['price']} pièces"
    if item_id == "revive":
        return f"{item['price']} pièces"
    if item_id == "magnet":
        return "ACTIF" if save_data["magnet"] else f"{item['price']} pièces"
    trail = item.get("trail")
    if trail in save_data["unlocked_trails"]:
        return "ÉQUIPÉ" if save_data["trail"] == trail else "ÉQUIPER"
    return f"{item['price']} pièces"


def click_shop_item(item):
    item_id = item["id"]
    if item_id == "mode3d":
        buy_mode_3d()
        return
    if item_id == "revive":
        if save_data["revives"] >= 9:
            set_notice("Tu peux garder au maximum 9 jetons de sauvetage.")
        elif can_afford(item["price"]):
            spend_coins(item["price"])
            save_data["revives"] += 1
            save_game()
            set_notice("Jeton acheté ! Il te sauvera d'un crash une fois.")
        else:
            set_notice(f"Il te faut {item['price']} pièces.")
        return
    if item_id == "magnet":
        if save_data["magnet"]:
            set_notice("L'aimant à pièces est déjà actif !")
        elif can_afford(item["price"]):
            spend_coins(item["price"])
            save_data["magnet"] = True
            save_game()
            set_notice("Aimant activé ! Les pièces bonus viendront vers toi.")
        else:
            set_notice(f"Il te faut {item['price']} pièces.")
        return
    trail = item.get("trail")
    if trail:
        if trail in save_data["unlocked_trails"]:
            save_data["trail"] = trail
            save_game()
            set_notice(f"Trail {trail} équipé !")
        elif can_afford(item["price"]):
            spend_coins(item["price"])
            save_data["unlocked_trails"].append(trail)
            save_data["trail"] = trail
            save_game()
            set_notice(f"Trail {trail} débloqué et équipé !")
        else:
            set_notice(f"Il te faut {item['price']} pièces pour ce trail.")


SHOP_ROTATION_SECONDS = 10 * 60
SHOP_OFFER_COUNT = 5
SHOP_CATEGORIES = {
    "bird": ("OISEAU", "unlocked_birds", "bird", "skin"),
    "pipe": ("TUYAUX", "unlocked_pipes", "pipe", "tuyau"),
    "background": ("FOND", "unlocked_backgrounds", "background", "fond"),
    "trail": ("TRAÎNÉE", "unlocked_trails", "trail", "effet"),
    "hat": ("CHAPEAU", "unlocked_hats", "hat", "chapeau"),
    "glasses": ("LUNETTES", "unlocked_glasses", "glasses", "lunettes"),
}


def rotating_cosmetic_catalog():
    catalog = []
    for kind, choices in [
        ("bird", BIRDS), ("pipe", PIPES), ("background", BACKGROUNDS),
        ("trail", TRAILS), ("hat", HATS), ("glasses", GLASSES),
    ]:
        names = list(choices.keys())
        for index, name in enumerate(names):
            if (kind == "bird" and name in ("Classique", "Custom")) or \
               (kind == "pipe" and name == "Verts") or \
               (kind == "background" and name == "Ciel") or \
               (kind == "trail" and name == "Aucun") or \
               (kind == "hat" and name == "Aucun") or \
               (kind == "glasses" and name == "Aucune"):
                continue
            if kind == "bird":
                price = 80 + (index * 37) % 421
            elif kind == "hat":
                price = 100 + (index * 31) % 351
            elif kind == "glasses":
                price = 90 + (index * 29) % 311
            elif kind == "pipe":
                price = 120 + (index * 47) % 221
            elif kind == "background":
                price = 150 + (index * 53) % 251
            else:
                price = TRAIL_PRICES.get(name, 160 + index * 20)
            catalog.append({
                "id": f"{kind}::{name}",
                "kind": kind,
                "name": name,
                "price": int(price),
            })
    return catalog


def cosmetic_is_unlocked(item):
    group = SHOP_CATEGORIES[item["kind"]][1]
    return item["name"] in save_data[group]


def equip_rotating_item(item):
    key = SHOP_CATEGORIES[item["kind"]][2]
    save_data[key] = item["name"]
    save_game()


def get_rotating_offers():
    catalog = rotating_cosmetic_catalog()
    catalog_by_id = {item["id"]: item for item in catalog}
    offer_ids = save_data.get("shop_rotation_offers", [])
    offers = [catalog_by_id[item_id] for item_id in offer_ids if item_id in catalog_by_id]
    return offers


def ensure_shop_rotation(force=False):
    now = time.time()
    if not force and now < float(save_data.get("shop_rotation_at", 0.0)):
        current = get_rotating_offers()
        if len(current) >= SHOP_OFFER_COUNT:
            return current
    catalog = rotating_cosmetic_catalog()
    if dev_mode_enabled():
        pool = catalog[:]
    else:
        pool = [item for item in catalog if not cosmetic_is_unlocked(item)]
        if len(pool) < SHOP_OFFER_COUNT:
            pool = catalog[:]
    if not pool:
        pool = catalog[:]
    chosen = random.sample(pool, min(SHOP_OFFER_COUNT, len(pool)))
    save_data["shop_rotation_offers"] = [item["id"] for item in chosen]
    save_data["shop_rotation_at"] = now + SHOP_ROTATION_SECONDS
    save_game()
    return chosen


def buy_rotating_cosmetic(item):
    if cosmetic_is_unlocked(item):
        equip_rotating_item(item)
        set_notice(f"{item['name']} équipé !", 170)
        return
    if not can_afford(item["price"]):
        set_notice(f"Il te faut {item['price']} pièces pour cet objet.")
        return
    spend_coins(item["price"])
    group = SHOP_CATEGORIES[item["kind"]][1]
    save_data[group].append(item["name"])
    equip_rotating_item(item)
    set_notice(f"{item['name']} débloqué et équipé !", 210)


def refresh_shop_dev():
    if not dev_mode_enabled():
        set_notice("Le rafraîchissement instantané est réservé au mode développeur.")
        return
    offers = ensure_shop_rotation(force=True)
    set_notice(f"Boutique renouvelée : {len(offers)} nouvelles offres !", 180)


def unlock_developer_mode():
    """Débloque une sauvegarde 100 % pour les tests et le fun."""
    save_data["dev_mode"] = True
    save_data["coins"] = 999999
    save_data["unlocked_birds"] = list(BIRDS.keys())
    save_data["unlocked_pipes"] = list(PIPES.keys())
    save_data["unlocked_backgrounds"] = list(BACKGROUNDS.keys())
    save_data["unlocked_trails"] = list(TRAILS.keys())
    save_data["unlocked_hats"] = list(HATS.keys())
    save_data["unlocked_glasses"] = list(GLASSES.keys())
    save_data["unlocked_modes"] = ["classic", "3d"]
    save_data["revives"] = 9
    save_data["magnet"] = True
    all_mission_ids = [mission["id"] for mission in MISSIONS]
    save_data["claimed_missions"] = all_mission_ids[:]
    for mission in MISSIONS:
        stat = mission["stat"]
        save_data["stats"][stat] = max(save_data["stats"].get(stat, 0), mission["target"])
    save_data["stats"]["games"] = max(save_data["stats"].get("games", 0), 100)
    save_data["stats"]["pipes"] = max(save_data["stats"].get("pipes", 0), 1000)
    save_data["stats"]["x2_collected"] = max(save_data["stats"].get("x2_collected", 0), 100)
    save_data["stats"]["coin_pickups"] = max(save_data["stats"].get("coin_pickups", 0), 100)
    save_data["stats"]["best_run"] = max(save_data["stats"].get("best_run", 0), 100)
    save_data["stats"]["coins_earned"] = max(save_data["stats"].get("coins_earned", 0), 999999)
    save_data["daily_streak"] = 7
    save_data["last_daily_claim"] = date.today().isoformat()
    save_data["best_scores"] = sorted(set(save_data["best_scores"] + [100]), reverse=True)[:10]
    # Équipe quelques accessoires cool, tout en laissant les autres sélectionnables.
    if "Couronne royale" in HATS:
        save_data["hat"] = "Couronne royale"
    if "Lunettes néon" in GLASSES:
        save_data["glasses"] = "Lunettes néon"
    save_data["trail"] = "Étoiles"
    save_game()
    ensure_shop_rotation(force=True)
    set_notice("MODE DÉVELOPPEUR ACTIVÉ : sauvegarde 100 % et pièces infinies !", 300)


def draw_text_center(text, y, font=MEDIUM, color=WHITE, x=None):
    surf = font.render(str(text), True, color)
    rect = surf.get_rect(center=(WIDTH // 2 if x is None else int(x), int(y)))
    screen.blit(surf, rect)


def draw_button(rect, label, small=False, active=True):
    fill = (55, 67, 95) if active else (78, 80, 90)
    pygame.draw.rect(screen, fill, rect, border_radius=10)
    pygame.draw.rect(screen, (205, 215, 235), rect, 2, border_radius=10)
    text_font = SMALL if small else MEDIUM
    surf = text_font.render(label, True, WHITE)
    if surf.get_width() > rect.width - 12:
        surf = pygame.transform.smoothscale(surf, (rect.width - 12, surf.get_height()))
    screen.blit(surf, surf.get_rect(center=rect.center))


def draw_bird(x, y, color, scale=1.0):
    x, y = int(x), int(y)
    r = max(4, int(17 * scale))
    pygame.draw.circle(screen, color, (x, y), r)
    pygame.draw.ellipse(screen, (245, 145, 35),
                        (int(x - 10 * scale), int(y), max(2, int(16 * scale)), max(2, int(10 * scale))))
    pygame.draw.circle(screen, WHITE, (int(x + 7 * scale), int(y - 6 * scale)), max(3, int(6 * scale)))
    pygame.draw.circle(screen, BLACK, (int(x + 9 * scale), int(y - 6 * scale)), max(2, int(3 * scale)))
    pygame.draw.polygon(screen, (255, 135, 30), [
        (int(x + 14 * scale), int(y)),
        (int(x + 27 * scale), int(y + 4 * scale)),
        (int(x + 14 * scale), int(y + 8 * scale)),
    ])
    draw_bird_accessories(x, y, scale)


def draw_bird_accessories(x, y, scale=1.0):
    """Dessine les chapeaux au-dessus du crâne et les lunettes sur le visage."""
    hat_name = save_data.get("hat", "Aucun")
    hat = HATS.get(hat_name, HATS["Aucun"])
    style = hat["style"]
    color = hat["color"]
    dark = tuple(max(0, c - 55) for c in color)
    r = max(3, int(17 * scale))
    left = int(x - 12 * scale)
    right = int(x + 12 * scale)
    top = int(y - r - 5 * scale)
    unit = max(2, int(scale * 4))

    if style == "crown":
        pts = [(int(x-12*scale), top+int(10*scale)), (int(x-13*scale), top),
               (int(x-6*scale), top+int(5*scale)), (int(x), top-int(3*scale)),
               (int(x+6*scale), top+int(5*scale)), (int(x+13*scale), top),
               (int(x+12*scale), top+int(10*scale))]
        pygame.draw.polygon(screen, color, pts)
        pygame.draw.rect(screen, dark, (int(x-12*scale), top+int(8*scale), int(24*scale), max(2, int(4*scale))))
    elif style in ("cap", "beret", "beanie"):
        pygame.draw.ellipse(screen, color, (int(x-14*scale), top, int(28*scale), int(15*scale)))
        if style == "cap":
            pygame.draw.ellipse(screen, dark, (int(x-1*scale), top+int(8*scale), int(18*scale), int(5*scale)))
        elif style == "beanie":
            pygame.draw.rect(screen, dark, (int(x-12*scale), top+int(9*scale), int(24*scale), max(2, int(4*scale))))
            pygame.draw.circle(screen, color, (int(x), top), max(2, int(3*scale)))
        else:
            pygame.draw.circle(screen, dark, (int(x+5*scale), top+int(4*scale)), max(1, int(2*scale)))
    elif style == "tophat":
        pygame.draw.rect(screen, color, (int(x-8*scale), top-int(13*scale), int(16*scale), int(17*scale)), border_radius=max(1, int(2*scale)))
        pygame.draw.rect(screen, dark, (int(x-13*scale), top+int(2*scale), int(26*scale), max(2, int(4*scale))))
        pygame.draw.rect(screen, dark, (int(x-8*scale), top-int(1*scale), int(16*scale), max(2, int(3*scale))))
    elif style == "wizard":
        pygame.draw.polygon(screen, color, [(int(x-13*scale), top+int(11*scale)), (int(x+2*scale), top-int(22*scale)), (int(x+12*scale), top+int(11*scale))])
        pygame.draw.ellipse(screen, dark, (int(x-13*scale), top+int(7*scale), int(26*scale), int(7*scale)))
        pygame.draw.circle(screen, GOLD, (int(x+2*scale), top-int(7*scale)), max(1, int(2*scale)))
    elif style == "halo":
        pygame.draw.ellipse(screen, color, (int(x-10*scale), top-int(10*scale), int(20*scale), int(7*scale)), max(2, int(2*scale)))
    elif style == "pirate":
        pygame.draw.ellipse(screen, color, (int(x-14*scale), top+int(3*scale), int(28*scale), int(11*scale)))
        pygame.draw.rect(screen, dark, (int(x-11*scale), top+int(7*scale), int(22*scale), max(2, int(4*scale))))
        pygame.draw.circle(screen, WHITE, (int(x), top+int(9*scale)), max(1, int(2*scale)))
    elif style == "sombrero":
        pygame.draw.ellipse(screen, color, (int(x-20*scale), top+int(7*scale), int(40*scale), int(8*scale)))
        pygame.draw.ellipse(screen, dark, (int(x-12*scale), top-int(2*scale), int(24*scale), int(14*scale)))
        pygame.draw.arc(screen, GOLD, (int(x-17*scale), top+int(7*scale), int(34*scale), int(8*scale)), 0, 3.14, max(1, int(2*scale)))
    elif style == "cat":
        pygame.draw.polygon(screen, color, [(int(x-13*scale), top+int(9*scale)), (int(x-11*scale), top-int(9*scale)), (int(x-2*scale), top+int(5*scale))])
        pygame.draw.polygon(screen, color, [(int(x+3*scale), top+int(5*scale)), (int(x+12*scale), top-int(9*scale)), (int(x+14*scale), top+int(9*scale))])
    elif style == "space":
        # Casque qui entoure l'oiseau entier.
        helmet = pygame.Rect(int(x-23*scale), int(y-22*scale), int(54*scale), int(44*scale))
        pygame.draw.ellipse(screen, dark, helmet, max(3, int(5*scale)))
        pygame.draw.ellipse(screen, color, helmet, max(2, int(3*scale)))
        visor = pygame.Rect(int(x-15*scale), int(y-10*scale), int(29*scale), int(17*scale))
        pygame.draw.ellipse(screen, (75, 150, 190), visor)
        pygame.draw.arc(screen, WHITE, visor, 0.2, 2.6, max(1, int(scale*2)))
    elif style == "flower":
        for angle in range(0, 360, 60):
            import math
            px = int(x + math.cos(math.radians(angle)) * 7 * scale)
            py = int(top + math.sin(math.radians(angle)) * 4 * scale)
            pygame.draw.circle(screen, color, (px, py), max(2, int(4*scale)))
        pygame.draw.circle(screen, GOLD, (int(x), top), max(2, int(3*scale)))
    elif style == "headphones":
        pygame.draw.arc(screen, color, (int(x-15*scale), top-int(4*scale), int(30*scale), int(29*scale)), 0, 3.14, max(2, int(3*scale)))
        pygame.draw.rect(screen, color, (int(x-16*scale), top+int(9*scale), max(2, int(5*scale)), max(5, int(9*scale))), border_radius=2)
        pygame.draw.rect(screen, color, (int(x+11*scale), top+int(9*scale), max(2, int(5*scale)), max(5, int(9*scale))), border_radius=2)
    elif style == "mushroom":
        pygame.draw.ellipse(screen, color, (int(x-16*scale), top, int(32*scale), int(17*scale)))
        pygame.draw.rect(screen, (245, 230, 200), (int(x-5*scale), top+int(8*scale), int(10*scale), int(8*scale)))
        for dx in (-7, 0, 7):
            pygame.draw.circle(screen, WHITE, (int(x+dx*scale), top+int(6*scale)), max(1, int(2*scale)))
    elif style == "cowboy":
        pygame.draw.ellipse(screen, dark, (int(x-19*scale), top+int(7*scale), int(38*scale), int(8*scale)))
        pygame.draw.polygon(screen, color, [(int(x-12*scale), top+int(10*scale)), (int(x-8*scale), top), (int(x+8*scale), top), (int(x+12*scale), top+int(10*scale))])
        pygame.draw.rect(screen, GOLD, (int(x-8*scale), top+int(7*scale), int(16*scale), max(2, int(3*scale))))
    elif style == "horns":
        pygame.draw.polygon(screen, color, [(int(x-12*scale), top+int(10*scale)), (int(x-10*scale), top-int(7*scale)), (int(x-2*scale), top+int(5*scale))])
        pygame.draw.polygon(screen, color, [(int(x+3*scale), top+int(5*scale)), (int(x+11*scale), top-int(7*scale)), (int(x+13*scale), top+int(10*scale))])
    elif style == "knight":
        pygame.draw.arc(screen, color, (int(x-14*scale), top-int(8*scale), int(28*scale), int(26*scale)), 3.14, 6.28, max(2, int(4*scale)))
        pygame.draw.rect(screen, color, (int(x-13*scale), top+int(3*scale), int(26*scale), max(2, int(4*scale))))
        pygame.draw.circle(screen, WHITE, (int(x+7*scale), top+int(5*scale)), max(1, int(2*scale)))

    # Les lunettes sont dessinées en dernier pour vraiment passer par-dessus les yeux.
    glasses_name = save_data.get("glasses", "Aucune")
    glasses = GLASSES.get(glasses_name, GLASSES["Aucune"])
    gstyle = glasses["style"]
    gcolor = glasses["color"]
    if gstyle == "none":
        return
    ey = int(y - 5 * scale)
    lx, rx = int(x + 1 * scale), int(x + 12 * scale)
    rad = max(2, int(5 * scale))
    linew = max(1, int(2 * scale))
    if gstyle == "visor":
        pygame.draw.rect(screen, gcolor, (int(x-3*scale), int(ey-5*scale), int(21*scale), int(10*scale)), border_radius=max(2, int(3*scale)))
        pygame.draw.line(screen, WHITE, (int(x), ey-int(2*scale)), (int(x+14*scale), ey-int(2*scale)), max(1, int(scale)))
    elif gstyle == "heart":
        for cx in (lx, rx):
            pygame.draw.circle(screen, gcolor, (cx-int(2*scale), ey), rad)
            pygame.draw.circle(screen, gcolor, (cx+int(2*scale), ey), rad)
            pygame.draw.polygon(screen, gcolor, [(cx-int(6*scale), ey), (cx+int(6*scale), ey), (cx, ey+int(7*scale))])
    elif gstyle == "star":
        for cx in (lx, rx):
            pts = []
            for j in range(10):
                import math
                angle = -math.pi/2 + j*math.pi/5
                rr = (6 if j % 2 == 0 else 3) * scale
                pts.append((int(cx + math.cos(angle)*rr), int(ey + math.sin(angle)*rr)))
            pygame.draw.polygon(screen, gcolor, pts)
    elif gstyle == "monocle":
        pygame.draw.circle(screen, gcolor, (rx, ey), rad+1, linew)
        pygame.draw.line(screen, gcolor, (rx, ey+rad), (rx, ey+rad+int(7*scale)), linew)
    elif gstyle == "3d":
        pygame.draw.rect(screen, (245, 60, 75), (lx-rad, ey-rad, 2*rad, 2*rad))
        pygame.draw.rect(screen, (60, 190, 255), (rx-rad, ey-rad, 2*rad, 2*rad))
        pygame.draw.line(screen, gcolor, (lx+rad, ey), (rx-rad, ey), linew)
    elif gstyle == "sport":
        pygame.draw.ellipse(screen, gcolor, (lx-rad, ey-rad, int(11*scale), int(8*scale)))
        pygame.draw.ellipse(screen, gcolor, (rx-rad, ey-rad, int(11*scale), int(8*scale)))
        pygame.draw.line(screen, gcolor, (lx+rad, ey), (rx-rad, ey), linew)
    else:
        lens_fill = (35, 45, 60) if gstyle == "dark" else tuple(max(0, c-25) for c in gcolor)
        if gstyle == "pixel":
            pygame.draw.rect(screen, lens_fill, (lx-rad, ey-rad, 2*rad, 2*rad))
            pygame.draw.rect(screen, gcolor, (lx-rad, ey-rad, 2*rad, 2*rad), linew)
            pygame.draw.rect(screen, lens_fill, (rx-rad, ey-rad, 2*rad, 2*rad))
            pygame.draw.rect(screen, gcolor, (rx-rad, ey-rad, 2*rad, 2*rad), linew)
        else:
            pygame.draw.circle(screen, lens_fill, (lx, ey), rad)
            pygame.draw.circle(screen, gcolor, (lx, ey), rad, linew)
            pygame.draw.circle(screen, lens_fill, (rx, ey), rad)
            pygame.draw.circle(screen, gcolor, (rx, ey), rad, linew)
        pygame.draw.line(screen, gcolor, (lx+rad, ey), (rx-rad, ey), linew)
        pygame.draw.line(screen, gcolor, (int(x-7*scale), ey-int(2*scale)), (lx-rad, ey), linew)


def draw_coin(x, y, radius=14):
    x, y = int(x), int(y)
    pygame.draw.circle(screen, (140, 90, 15), (x, y), radius + 2)
    pygame.draw.circle(screen, GOLD, (x, y), radius)
    pygame.draw.circle(screen, (255, 240, 150), (x - 3, y - 4), max(2, radius // 3))
    pygame.draw.circle(screen, (210, 145, 20), (x, y), radius - 4, 2)
    label = TINY.render("$", True, (110, 70, 0))
    screen.blit(label, label.get_rect(center=(x + 1, y + 1)))


def draw_x2_pickup(x, y):
    x, y = int(x), int(y)
    pygame.draw.circle(screen, (255, 185, 20), (x, y), 21)
    pygame.draw.circle(screen, (255, 224, 55), (x, y), 18)
    pygame.draw.circle(screen, (255, 245, 160), (x - 6, y - 7), 6)
    pygame.draw.circle(screen, (228, 155, 20), (x - 7, y + 8), 6)
    pygame.draw.circle(screen, (255, 220, 45), (x - 7, y + 8), 4)
    label = pygame.font.SysFont("Arial", 15, bold=True).render("x2", True, (90, 55, 0))
    screen.blit(label, label.get_rect(center=(x + 7, y + 2)))


def draw_background(color, mode="classic"):
    screen.fill(color)
    if mode == "3d":
        # Fausse perspective : tunnel et grille qui convergent vers l'horizon.
        horizon = 350
        floor = (22, 27, 53)
        pygame.draw.polygon(screen, floor, [(0, horizon), (WIDTH, horizon), (WIDTH, HEIGHT), (0, HEIGHT)])
        pygame.draw.circle(screen, (255, 224, 145), (WIDTH // 2, horizon - 32), 24)
        for i in range(1, 9):
            x = int(WIDTH * i / 9)
            pygame.draw.line(screen, (63, 77, 130), (WIDTH // 2, horizon), (x, HEIGHT), 1)
        for i in range(1, 8):
            factor = i / 7
            y = horizon + int((HEIGHT - horizon) * factor * factor)
            pygame.draw.line(screen, (63, 77, 130), (0, y), (WIDTH, y), 1)
        pygame.draw.line(screen, (115, 140, 220), (0, horizon), (WIDTH, horizon), 2)
        return
    if color[0] < 60 and color[1] < 65:
        random.seed(17)
        for _ in range(48):
            sx = random.randint(0, WIDTH)
            sy = random.randint(0, HEIGHT - 80)
            pygame.draw.circle(screen, (235, 235, 255), (sx, sy), random.choice((1, 1, 2)))
        random.seed()
    else:
        for x, y, r in [(75, 100, 20), (100, 93, 26), (125, 104, 19),
                        (365, 145, 18), (390, 137, 25), (414, 148, 17)]:
            pygame.draw.circle(screen, (245, 248, 255), (x, y), r)


def draw_ground(mode="classic"):
    if mode == "3d":
        return
    pygame.draw.rect(screen, (220, 190, 120), (0, HEIGHT - 55, WIDTH, 55))
    pygame.draw.line(screen, GREEN, (0, HEIGHT - 55), (WIDTH, HEIGHT - 55), 5)
    for x in range(0, WIDTH, 32):
        pygame.draw.line(screen, (190, 158, 95), (x, HEIGHT - 37), (x + 15, HEIGHT - 37), 2)


def draw_pipe(x, gap_y, pipe_color, mode="classic"):
    x = int(x)
    gap = 175
    pw = 75
    bottom_y = gap_y + gap
    darker = tuple(max(0, c - 42) for c in pipe_color)
    lighter = tuple(min(255, c + 25) for c in pipe_color)
    if mode == "classic":
        pygame.draw.rect(screen, pipe_color, (x, 0, pw, gap_y))
        pygame.draw.rect(screen, darker, (x, 0, 8, gap_y))
        pygame.draw.rect(screen, lighter, (x + pw - 9, 0, 9, gap_y))
        pygame.draw.rect(screen, pipe_color, (x - 5, gap_y - 25, pw + 10, 25))
        pygame.draw.rect(screen, darker, (x - 5, gap_y - 25, 8, 25))
        pygame.draw.rect(screen, pipe_color, (x, bottom_y, pw, max(1, HEIGHT - bottom_y - 55)))
        pygame.draw.rect(screen, darker, (x, bottom_y, 8, max(1, HEIGHT - bottom_y - 55)))
        pygame.draw.rect(screen, lighter, (x + pw - 9, bottom_y, 9, max(1, HEIGHT - bottom_y - 55)))
        pygame.draw.rect(screen, pipe_color, (x - 5, bottom_y, pw + 10, 25))
        pygame.draw.rect(screen, darker, (x - 5, bottom_y, 8, 25))
        return

    # Version pseudo-3D : les obstacles rapetissent à l'horizon et grossissent à l'approche.
    horizon = 350
    def depth(pos_x):
        return max(0.0, min(1.0, (WIDTH + 10 - pos_x) / (WIDTH + 10 - 105)))
    def project(y, scale):
        return int(horizon + (y - horizon) * (0.30 + 0.70 * scale))
    d0 = depth(x)
    d1 = depth(x + pw)
    w0 = int(17 + 58 * d0)
    x0 = x
    x1 = x + max(17, int(17 + 58 * d1))
    top0, top1 = project(0, d0), project(0, d1)
    gap0, gap1 = project(gap_y, d0), project(gap_y, d1)
    bottom0, bottom1 = project(bottom_y, d0), project(bottom_y, d1)
    ground0, ground1 = project(HEIGHT - 55, d0), project(HEIGHT - 55, d1)
    # Partie supérieure et sa face latérale.
    pygame.draw.polygon(screen, pipe_color, [(x0, top0), (x1, top1), (x1, gap1), (x0, gap0)])
    pygame.draw.polygon(screen, darker, [(x1 - 3, top1), (x1 + max(3, w0 // 4), top1 + 3),
                                         (x1 + max(3, w0 // 4), gap1 + 3), (x1 - 3, gap1)])
    pygame.draw.polygon(screen, lighter, [(x0 + 3, top0), (x0 + max(4, w0 // 5), top0),
                                         (x0 + max(4, w0 // 5), gap0), (x0 + 3, gap0)])
    # Bord sous le premier obstacle.
    pygame.draw.polygon(screen, lighter, [(x0, gap0 - 8), (x1, gap1 - 8),
                                          (x1, gap1 + 4), (x0, gap0 + 4)])
    # Partie inférieure.
    pygame.draw.polygon(screen, pipe_color, [(x0, bottom0), (x1, bottom1), (x1, ground1), (x0, ground0)])
    pygame.draw.polygon(screen, darker, [(x1 - 3, bottom1), (x1 + max(3, w0 // 4), bottom1 + 3),
                                         (x1 + max(3, w0 // 4), ground1 + 3), (x1 - 3, ground1)])
    pygame.draw.polygon(screen, lighter, [(x0 + 3, bottom0), (x0 + max(4, w0 // 5), bottom0),
                                          (x0 + max(4, w0 // 5), ground0), (x0 + 3, ground0)])
    pygame.draw.polygon(screen, lighter, [(x0, bottom0 - 4), (x1, bottom1 - 4),
                                          (x1, bottom1 + 8), (x0, bottom0 + 8)])


def update_trail_particles():
    """Émet de petites particules qui dérivent et s'éteignent derrière l'oiseau."""
    trail_name = save_data.get("trail", "Aucun")
    color = TRAILS.get(trail_name)
    particles = game["particles"]

    for particle in particles[:]:
        particle["x"] += particle["vx"]
        particle["y"] += particle["vy"]
        particle["life"] -= 1
        if particle["life"] <= 0:
            particles.remove(particle)

    if color is None or game["over"] or not game["started"] or game["revive_countdown"] > 0:
        return

    game["trail_frame"] += 1
    if game["trail_frame"] % 3 == 0:
        particles.append({
            "x": 91,
            "y": game["bird_y"] + random.randint(-8, 8),
            "vx": random.uniform(-2.5, -0.7),
            "vy": random.uniform(-1.3, 1.3),
            "life": random.randint(16, 28),
            "max_life": 28,
            "color": color,
            "kind": trail_name,
        })


def new_game(mode="classic"):
    return {
        "mode": mode,
        "bird_y": HEIGHT // 2,
        "velocity": 0.0,
        "pipes": [],
        "score": 0,
        "started": False,
        "over": False,
        "result_saved": False,
        "revive_used": False,
        "pipes_passed": 0,
        "pickups": [],
        "x2_remaining": 0,
        "revive_countdown": 0,
        "revive_y": HEIGHT // 2,
        "revive_invuln": 0,
        "particles": [],
        "trail_frame": 0,
    }


game = new_game()
scene = "menu"
menu_page = "main"
notice = ""
notice_timer = 0
shop_tab = "rotation"
custom_tab = "bird"
custom_env_mode = "background"
rgb_edit_channel = None
rgb_edit_buffer = ""
color_drag_mode = None
dev_key_buffer = []
DEV_KEY_SEQUENCE = [pygame.K_KP1, pygame.K_KP2, pygame.K_KP3, pygame.K_KP4]


def build_color_wheel(size=144):
    wheel = pygame.Surface((size, size), pygame.SRCALPHA)
    center = (size - 1) / 2
    radius = center - 2
    for py in range(size):
        for px in range(size):
            dx, dy = px - center, py - center
            distance = (dx*dx + dy*dy) ** 0.5
            if distance <= radius:
                hue = (math.atan2(dy, dx) / (2 * math.pi)) % 1.0
                saturation = min(1.0, distance / radius)
                rgb = colorsys.hsv_to_rgb(hue, saturation, 1.0)
                wheel.set_at((px, py), tuple(round(v*255) for v in rgb) + (255,))
    return wheel


import math
COLOR_WHEEL = build_color_wheel()


def start_game(mode="classic"):
    global game, scene
    if mode == "3d" and "3d" not in save_data["unlocked_modes"]:
        buy_mode_3d()
        return
    game = new_game(mode)
    game["pipes"] = [{"x": WIDTH, "gap_y": random.randint(170, HEIGHT - 230), "scored": False}]
    scene = "game"


def finish_game():
    if game["result_saved"]:
        return
    game["over"] = True
    game["result_saved"] = True
    save_data["stats"]["games"] += 1
    save_data["stats"]["best_run"] = max(save_data["stats"]["best_run"], int(game["score"]))
    add_score(game["score"])
    award_coins(COINS_PER_GAME)
    save_game()
    check_missions()


def handle_crash():
    if game["over"] or game["revive_countdown"] > 0:
        return
    if save_data["revives"] > 0 and not game["revive_used"]:
        save_data["revives"] -= 1
        game["revive_used"] = True
        game["revive_y"] = max(35, min(HEIGHT - 75, int(game["bird_y"])))
        game["revive_countdown"] = 180  # 3 secondes à 60 FPS
        game["velocity"] = 0.0
        set_notice("Jeton utilisé : sauvetage dans 3 secondes...", 180)
        save_game()
    else:
        finish_game()


def buy_or_collect_pickups():
    # Appelé pendant la partie : les pièces et la bulle x2 sont persistantes.
    bird_rect = pygame.Rect(105 - 18, int(game["bird_y"]) - 18, 36, 36)
    for pickup in game["pickups"]:
        attached_pipe = pickup.get("attached_pipe")
        if attached_pipe is not None:
            pickup["x"] = attached_pipe["x"] + 37
            pickup["y"] = max(attached_pipe["gap_y"] + 42,
                              min(attached_pipe["gap_y"] + 133, pickup["y"])) if pickup["type"] == "coin" else max(
                                  attached_pipe["gap_y"] + 30,
                                  min(attached_pipe["gap_y"] + 145, pickup["y"]))
        else:
            pickup["x"] -= 3.0
        if pickup["type"] == "coin" and save_data["magnet"]:
            dx = 105 - pickup["x"]
            dy = game["bird_y"] - pickup["y"]
            if abs(dx) < 210:
                pickup["x"] += max(-5.0, min(0.0, dx * 0.035))
                pickup["y"] += max(-5.0, min(5.0, dy * 0.08))
        pickup_rect = pygame.Rect(int(pickup["x"]) - 20, int(pickup["y"]) - 20, 40, 40)
        if not pickup.get("collected") and bird_rect.colliderect(pickup_rect):
            pickup["collected"] = True
            if pickup["type"] == "x2":
                game["x2_remaining"] = 3
                save_data["stats"]["x2_collected"] += 1
                save_game()
                check_missions()
                set_notice("BONUS x2 activé pour les 3 prochains tuyaux !", 150)
            elif pickup["type"] == "coin":
                award_coins(5)
                save_data["stats"]["coin_pickups"] += 1
                save_game()
                check_missions()
                set_notice("+5 pièces bonus !", 90)
    game["pickups"] = [p for p in game["pickups"] if p["x"] > -35 and not p.get("collected")]


def draw_menu_base():
    draw_background(BACKGROUNDS[save_data["background"]])
    draw_ground()
    draw_text_center("FLAPPY BIRD DELUXE", 48, FONT)
    draw_text_center(coins_label(), 88, MEDIUM, GOLD)


def main_button_rects():
    # Barre utilitaire en haut, puis les activités principales dans l'ordre demandé.
    return {
        "stats": pygame.Rect(8, 108, 160, 34),
        "ranking": pygame.Rect(180, 108, 160, 34),
        "daily": pygame.Rect(352, 108, 160, 34),
        "play": pygame.Rect(25, 165, 220, 58),
        "mode3d": pygame.Rect(275, 165, 220, 58),
        "custom": pygame.Rect(25, 245, 470, 48),
        "shop": pygame.Rect(25, 305, 470, 48),
        "missions": pygame.Rect(25, 365, 470, 48),
    }


def draw_menu():
    draw_menu_base()
    if menu_page == "main":
        rects = main_button_rects()
        draw_button(rects["stats"], "STATISTIQUES", small=True)
        draw_button(rects["ranking"], "CLASSEMENT", small=True)
        draw_button(rects["daily"], "CADEAU QUOTIDIEN", small=True)
        draw_button(rects["play"], "JOUER CLASSIQUE")
        mode_label = "JOUER EN 3D" if "3d" in save_data["unlocked_modes"] else "DÉBLOQUER 3D · 100 pièces"
        draw_button(rects["mode3d"], mode_label, small=True)
        draw_button(rects["custom"], "SKINS")
        draw_button(rects["shop"], "BOUTIQUE")
        draw_button(rects["missions"], "MISSIONS")
        draw_text_center("Classique : 1 pièce/tuyau · 3D : 2 pièces/tuyau", 450, SMALL)
        draw_text_center("Espace / clic gauche : sauter · Échap : retour", 480, SMALL)
        draw_text_center("Ramasse les bulles x2 et les pièces dorées !", 510, SMALL, GOLD)
        draw_text_center(f"Jetons de sauvetage : {save_data['revives']}  |  Aimant : {'OUI' if save_data['magnet'] else 'NON'}", 550, TINY)
        if dev_mode_enabled():
            draw_text_center("MODE DÉVELOPPEUR · SAUVEGARDE 100 %", 590, TINY, (105, 255, 170))
    elif menu_page == "shop":
        draw_text_center("BOUTIQUE", 126, FONT)
        draw_button(pygame.Rect(20, 145, 230, 36), "OFFRES ROTATIVES", small=True, active=(shop_tab == "rotation"))
        draw_button(pygame.Rect(270, 145, 230, 36), "AMÉLIORATIONS", small=True, active=(shop_tab == "upgrades"))
        if shop_tab == "rotation":
            offers = ensure_shop_rotation()
            for i, item in enumerate(offers[:SHOP_OFFER_COUNT]):
                y = 190 + i * 50
                rect = pygame.Rect(25, y, WIDTH - 50, 43)
                unlocked = cosmetic_is_unlocked(item)
                if unlocked:
                    status = "ÉQUIPER" if save_data[SHOP_CATEGORIES[item["kind"]][2]] != item["name"] else "ÉQUIPÉ"
                else:
                    status = f"{item['price']} pièces"
                category = SHOP_CATEGORIES[item["kind"]][0]
                draw_button(rect, f"{category} · {item['name']} — {status}", small=True, active=(status != "ÉQUIPÉ"))
                # Aperçu visuel de l'objet exact proposé.
                if item["kind"] == "bird":
                    pygame.draw.circle(screen, bird_color(item["name"]), (43, y+21), 9)
                    pygame.draw.circle(screen, WHITE, (46, y+18), 3)
                    pygame.draw.circle(screen, BLACK, (47, y+18), 1)
                elif item["kind"] == "pipe":
                    c = PIPES[item["name"]]
                    pygame.draw.rect(screen, c, (36, y+8, 15, 27), border_radius=3)
                    pygame.draw.rect(screen, tuple(max(0,v-35) for v in c), (33,y+8,21,5), border_radius=2)
                elif item["kind"] == "background":
                    pygame.draw.rect(screen, BACKGROUNDS[item["name"]], (34, y+8, 20, 27), border_radius=3)
                elif item["kind"] == "hat":
                    # Rend le vrai modèle du chapeau vendu sur un petit oiseau.
                    old_hat, old_glasses = save_data["hat"], save_data["glasses"]
                    save_data["hat"], save_data["glasses"] = item["name"], "Aucune"
                    draw_bird(43, y+23, BIRDS["Classique"], 0.55)
                    save_data["hat"], save_data["glasses"] = old_hat, old_glasses
                elif item["kind"] == "glasses":
                    # Même principe pour les lunettes proposées.
                    old_hat, old_glasses = save_data["hat"], save_data["glasses"]
                    save_data["hat"], save_data["glasses"] = "Aucun", item["name"]
                    draw_bird(43, y+23, BIRDS["Classique"], 0.55)
                    save_data["hat"], save_data["glasses"] = old_hat, old_glasses
                elif item["kind"] == "trail" and TRAILS[item["name"]]:
                    pygame.draw.circle(screen, TRAILS[item["name"]], (43, y+21), 7)
                    pygame.draw.circle(screen, WHITE, (41, y+19), 2)
            # Offre permanente : elle ne change pas avec la rotation.
            rgb_owned = "Custom" in save_data["unlocked_birds"]
            draw_button(pygame.Rect(25, 445, WIDTH-50, 43), f"COULEUR RGB D'OISEAU — {'ACHETÉE' if rgb_owned else '100 pièces'}", small=True, active=not rgb_owned)
            pygame.draw.circle(screen, bird_color("Custom"), (43, 466), 9)
            pygame.draw.circle(screen, WHITE, (46, 463), 3)
            if dev_mode_enabled():
                draw_button(pygame.Rect(70, 500, 380, 36), "↻ RAFRAÎCHIR LA BOUTIQUE (DEV)")
            else:
                seconds = max(0, int(save_data.get("shop_rotation_at", 0) - time.time()))
                draw_text_center(f"Prochaine rotation dans {seconds//60:02d}:{seconds%60:02d}", 520, SMALL, GOLD)
                draw_text_center("Les 5 offres changent toutes les 10 minutes.", 543, TINY)
        else:
            for i, item in enumerate(shop_items()):
                rect = pygame.Rect(35, 190 + i * 49, WIDTH - 70, 42)
                status = shop_item_status(item)
                label = f"{item['label']} — {status}"
                draw_button(rect, label, small=True, active=(status not in ("ACTIF", "DÉBLOQUÉ", "ÉQUIPÉ")))
        draw_button(pygame.Rect(145, 580, 230, 42), "RETOUR")
    elif menu_page == "custom":
        # L'aperçu occupe tout l'écran : pas de sol ni de tuyaux dans l'aperçu du fond.
        draw_background(BACKGROUNDS[save_data["background"]])
        draw_text_center("PERSONNALISATION", 58, FONT)
        draw_text_center(coins_label(), 91, SMALL, GOLD)
        draw_button(pygame.Rect(25, 112, 225, 42), "OISEAU", active=(custom_tab == "bird"))
        draw_button(pygame.Rect(270, 112, 225, 42), "ENVIRONNEMENT", small=True, active=(custom_tab == "environment"))

        if custom_tab == "bird":
            # Aperçu agrandi ; chaque paire de flèches garde le même espacement horizontal.
            bird_x, bird_y, bird_scale = WIDTH // 2, 355, 2.25
            draw_text_center("SKIN DE L'OISEAU", 190, SMALL)
            draw_button(pygame.Rect(82, 213, 44, 40), "‹")
            draw_button(pygame.Rect(394, 213, 44, 40), "›")
            draw_text_center(save_data["bird"], 235, MEDIUM)

            draw_text_center("CHAPEAU", 270, TINY)
            draw_button(pygame.Rect(82, 276, 44, 36), "‹", small=True)
            draw_button(pygame.Rect(394, 276, 44, 36), "›", small=True)

            draw_text_center("LUNETTES", 323, TINY)
            draw_button(pygame.Rect(82, 328, 44, 36), "‹", small=True)
            draw_button(pygame.Rect(394, 328, 44, 36), "›", small=True)

            draw_bird(bird_x, bird_y, bird_color(save_data["bird"]), bird_scale)

            if save_data["bird"] == "Custom":
                draw_text_center(f"Chapeau : {save_data['hat']}", 420, TINY, x=100)
                draw_text_center(f"Lunettes : {save_data['glasses']}", 447, TINY, x=100)
                draw_text_center(f"Traînée : {save_data['trail']}", 530, TINY, x=100)
            else:
                draw_text_center(f"Chapeau : {save_data['hat']}", 420, SMALL)
                draw_text_center(f"Lunettes : {save_data['glasses']}", 447, SMALL)
                draw_text_center(f"Traînée : {save_data['trail']}", 487, SMALL)
            draw_button(pygame.Rect(82, 498, 44, 38), "‹")
            draw_button(pygame.Rect(394, 498, 44, 38), "›")
            color = TRAILS.get(save_data["trail"])
            if save_data["bird"] != "Custom":
                if color:
                    for i in range(5):
                        pygame.draw.circle(screen, color, (190 + i * 12, 530), max(2, 7 - i))
                else:
                    draw_text_center("Aucun effet", 530, TINY)
            if save_data["bird"] == "Custom":
                wheel_rect = COLOR_WHEEL.get_rect(center=(WIDTH//2, 475))
                screen.blit(COLOR_WHEEL, wheel_rect)
                hsv = save_data.get("custom_bird_hsv", [0.91, 0.69, 1.0])
                angle = hsv[0] * 2 * math.pi
                radius = hsv[1] * 69
                marker = (int(WIDTH//2 + math.cos(angle)*radius), int(475 + math.sin(angle)*radius))
                pygame.draw.circle(screen, WHITE, marker, 6, 2)
                pygame.draw.circle(screen, BLACK, marker, 2)
                pygame.draw.rect(screen, (50, 50, 65), (155, 556, 210, 10), border_radius=5)
                for i in range(210):
                    v = i / 209
                    c = colorsys.hsv_to_rgb(hsv[0], hsv[1], v)
                    pygame.draw.line(screen, tuple(round(z*255) for z in c), (155+i, 556), (155+i, 565))
                pygame.draw.circle(screen, WHITE, (155 + int(hsv[2]*209), 561), 7, 2)
                rgb = save_data.get("custom_bird_rgb", [255, 80, 190])
                # Trois champs éditables : on peut saisir directement chaque composante RGB.
                for channel, label, x in ((0, "R", 105), (1, "G", 220), (2, "B", 335)):
                    box = pygame.Rect(x - 35, 578, 70, 29)
                    active = (rgb_edit_channel == channel)
                    pygame.draw.rect(screen, (70, 82, 110) if active else (38, 43, 62), box, border_radius=6)
                    pygame.draw.rect(screen, (110, 205, 255) if active else (105, 115, 140), box, 2, border_radius=6)
                    value_text = (rgb_edit_buffer if rgb_edit_buffer else str(rgb[channel])) if active else str(rgb[channel])
                    draw_text_center(f"{label}: {value_text}", 583, TINY, WHITE, x=x)
                draw_text_center("Clique puis tape 0-255 ; glisse sur la roue ou la barre", 610, TINY)
            else:
                draw_text_center("Les flèches près de chaque élément changent uniquement celui-ci.", 566, TINY)
        else:
            # Ne pas redessiner le fond après les boutons : cela les masquait et empêchait
            # de revenir à l'onglet Oiseau ou de choisir l'aperçu des tuyaux.
            draw_button(pygame.Rect(35, 170, 215, 40), "FOND", small=True, active=(custom_env_mode == "background"))
            draw_button(pygame.Rect(270, 170, 215, 40), "TUYAUX", small=True, active=(custom_env_mode == "pipe"))
            if custom_env_mode == "background":
                # Fond plein écran sans aucun tuyau : on voit clairement la couleur choisie.
                draw_text_center("APERÇU DU FOND", 260, MEDIUM)
                draw_text_center(save_data["background"], 310, FONT)
                draw_button(pygame.Rect(82, 365, 44, 44), "‹")
                draw_button(pygame.Rect(394, 365, 44, 44), "›")
            else:
                # Échantillon de tuyau isolé au centre : il ne recouvre pas les onglets.
                pipe_color = PIPES[save_data["pipe"]]
                pipe_dark = tuple(max(0, c - 42) for c in pipe_color)
                pipe_light = tuple(min(255, c + 25) for c in pipe_color)
                pygame.draw.rect(screen, pipe_color, (218, 270, 84, 190), border_radius=5)
                pygame.draw.rect(screen, pipe_dark, (218, 270, 10, 190), border_radius=3)
                pygame.draw.rect(screen, pipe_light, (292, 270, 10, 190), border_radius=3)
                pygame.draw.rect(screen, pipe_color, (207, 260, 106, 28), border_radius=5)
                pygame.draw.rect(screen, pipe_dark, (207, 260, 10, 28), border_radius=3)
                pygame.draw.rect(screen, pipe_light, (303, 260, 10, 28), border_radius=3)
                pygame.draw.rect(screen, pipe_color, (207, 442, 106, 28), border_radius=5)
                pygame.draw.rect(screen, pipe_dark, (207, 442, 10, 28), border_radius=3)
                pygame.draw.rect(screen, pipe_light, (303, 442, 10, 28), border_radius=3)
                draw_text_center("APERÇU DES TUYAUX", 230, MEDIUM)
                draw_text_center(save_data["pipe"], 495, FONT)
                draw_button(pygame.Rect(82, 530, 44, 44), "‹")
                draw_button(pygame.Rect(394, 530, 44, 44), "›")
        draw_button(pygame.Rect(145, 620, 230, 38), "RETOUR")
    elif menu_page == "daily":
        reward, streak, already = today_reward_preview()
        draw_text_center("CADEAU QUOTIDIEN", 155, FONT)
        draw_coin(WIDTH // 2, 235, 29)
        draw_text_center("Chaque jour, récupère des pièces gratuites !", 295, SMALL)
        draw_text_center(f"Récompense aujourd'hui : {reward if not already else 0} pièces", 335, MEDIUM, GOLD)
        draw_text_center(f"Série prévue : {streak} jour(s) consécutif(s)", 375, SMALL)
        draw_text_center("La récompense monte jusqu'à 50 pièces.", 405, SMALL)
        if already:
            seconds = seconds_until_next_daily()
            draw_text_center(f"Prochain cadeau dans {seconds//3600:02d}:{(seconds%3600)//60:02d}:{seconds%60:02d}", 432, SMALL, GOLD)
        else:
            draw_text_center("Prochain cadeau : disponible maintenant !", 432, SMALL, GOLD)
        draw_button(pygame.Rect(110, 450, 300, 48), "DÉJÀ RÉCUPÉRÉ" if already else "RÉCUPÉRER LE CADEAU", small=already)
        draw_button(pygame.Rect(145, 515, 230, 43), "RETOUR")
    elif menu_page == "missions":
        draw_text_center("MISSIONS", 130, FONT)
        draw_text_center("Les récompenses se récupèrent ici avec RÉCLAMER.", 157, TINY)
        claimed = set(save_data["claimed_missions"])
        stats = save_data["stats"]
        for i, mission in enumerate(MISSIONS):
            y = 180 + i * 64
            done = mission["id"] in claimed
            progress = min(stats.get(mission["stat"], 0), mission["target"])
            pygame.draw.rect(screen, (40, 48, 70), (20, y, WIDTH - 40, 55), border_radius=8)
            title_color = (125, 235, 150) if done else WHITE
            title_surf = SMALL.render(mission["title"], True, title_color)
            screen.blit(title_surf, (31, y + 5))
            desc_surf = TINY.render(mission["description"], True, WHITE)
            screen.blit(desc_surf, (31, y + 28))
            if done:
                button_label = "RÉCUPÉRÉE"
                button_active = False
            elif progress >= mission["target"]:
                button_label = "RÉCLAMER"
                button_active = True
            else:
                button_label = f"{progress}/{mission['target']}"
                button_active = False
            draw_button(pygame.Rect(370, y + 11, 125, 34), button_label, small=True, active=button_active)
            reward_surf = TINY.render(f"+{mission['reward']} pièces", True, GOLD)
            screen.blit(reward_surf, (31, y + 43))
        draw_button(pygame.Rect(145, 585, 230, 43), "RETOUR")
    elif menu_page == "ranking":
        draw_text_center("CLASSEMENT DES SCORES", 145, FONT)
        scores = save_data["best_scores"][:10]
        if not scores:
            draw_text_center("Aucune partie terminée pour l'instant.", 220, SMALL)
        else:
            for i, points in enumerate(scores):
                y = 200 + i * 34
                if i == 0:
                    color = GOLD
                else:
                    color = WHITE
                draw_text_center(f"{i + 1}.     {points} points", y, MEDIUM if i < 3 else SMALL, color)
        draw_button(pygame.Rect(145, 575, 230, 43), "RETOUR")
    elif menu_page == "stats":
        stats = save_data["stats"]
        draw_text_center("STATISTIQUES", 145, FONT)
        lines = [
            f"Parties terminées : {stats['games']}",
            f"Tuyaux franchis : {stats['pipes']}",
            f"Bulles x2 récupérées : {stats['x2_collected']}",
            f"Pièces bonus ramassées : {stats['coin_pickups']}",
            f"Pièces gagnées au total : {stats['coins_earned']}",
            f"Meilleur score en une partie : {stats['best_run']}",
            f"Jetons de sauvetage en stock : {save_data['revives']}",
        ]
        for i, line in enumerate(lines):
            draw_text_center(line, 220 + i * 42, SMALL)
        draw_button(pygame.Rect(145, 555, 230, 43), "RETOUR")

    if notice_timer > 0 and notice:
        pygame.draw.rect(screen, (28, 32, 48), (18, 642, WIDTH - 36, 36), border_radius=8)
        msg_surf = TINY.render(notice, True, GOLD)
        if msg_surf.get_width() > WIDTH - 45:
            msg_surf = pygame.transform.smoothscale(msg_surf, (WIDTH - 45, msg_surf.get_height()))
        screen.blit(msg_surf, msg_surf.get_rect(center=(WIDTH // 2, 660)))


def cycle_unlocked(unlocked_key, choices, current, direction):
    names = [name for name in choices if name in save_data[unlocked_key]]
    if not names:
        return current
    index = names.index(current) if current in names else 0
    return names[(index + direction) % len(names)]


def custom_row_at(pos):
    global custom_tab, custom_env_mode
    x, y = pos

    def cycle_item(key, choices, unlocked_key, direction):
        save_data[key] = cycle_unlocked(unlocked_key, choices, save_data[key], direction)
        save_game()

    if custom_tab == "bird":
        controls = [
            (pygame.Rect(82, 213, 44, 40), pygame.Rect(394, 213, 44, 40),
             "bird", BIRDS, "unlocked_birds"),
            (pygame.Rect(82, 276, 44, 36), pygame.Rect(394, 276, 44, 36),
             "hat", HATS, "unlocked_hats"),
            (pygame.Rect(82, 328, 44, 36), pygame.Rect(394, 328, 44, 36),
             "glasses", GLASSES, "unlocked_glasses"),
            (pygame.Rect(82, 498, 44, 38), pygame.Rect(394, 498, 44, 38),
             "trail", TRAILS, "unlocked_trails"),
        ]
        for left, right, key, choices, unlocked_key in controls:
            if left.collidepoint(pos):
                cycle_item(key, choices, unlocked_key, -1)
                return True
            if right.collidepoint(pos):
                cycle_item(key, choices, unlocked_key, 1)
                return True
    else:
        if pygame.Rect(35, 170, 215, 40).collidepoint(pos):
            custom_env_mode = "background"
            return True
        if pygame.Rect(270, 170, 215, 40).collidepoint(pos):
            custom_env_mode = "pipe"
            return True
        if custom_env_mode == "background":
            left, right = pygame.Rect(82, 365, 44, 44), pygame.Rect(394, 365, 44, 44)
            key, choices, unlocked_key = "background", BACKGROUNDS, "unlocked_backgrounds"
        else:
            left, right = pygame.Rect(82, 530, 44, 44), pygame.Rect(394, 530, 44, 44)
            key, choices, unlocked_key = "pipe", PIPES, "unlocked_pipes"
        if left.collidepoint(pos):
            cycle_item(key, choices, unlocked_key, -1)
            return True
        if right.collidepoint(pos):
            cycle_item(key, choices, unlocked_key, 1)
            return True
    return False


def coin_pickup_rect(item):
    return pygame.Rect(int(item["x"]) - 20, int(item["y"]) - 20, 40, 40)


def collides_with_pipe(pipe):
    bird_rect = pygame.Rect(105 - 15, int(game["bird_y"]) - 15, 30, 30)
    top_rect = pygame.Rect(int(pipe["x"]), 0, 75, pipe["gap_y"])
    bottom_rect = pygame.Rect(int(pipe["x"]), pipe["gap_y"] + 175, 75, HEIGHT)
    return bird_rect.colliderect(top_rect) or bird_rect.colliderect(bottom_rect)


def draw_game():
    mode = game["mode"]
    bg = BACKGROUNDS[save_data["background"]]
    draw_background(bg, mode)
    for pipe in game["pipes"]:
        draw_pipe(pipe["x"], pipe["gap_y"], PIPES[save_data["pipe"]], mode)
    for pickup in game["pickups"]:
        if pickup["type"] == "x2":
            draw_x2_pickup(pickup["x"], pickup["y"])
        else:
            draw_coin(pickup["x"], pickup["y"], 13)
    draw_ground(mode)
    # Particules animées qui dérivent derrière l'oiseau.
    for particle in game["particles"]:
        fade = max(0.15, particle["life"] / particle["max_life"])
        radius = max(1, int(5 * fade))
        px, py = int(particle["x"]), int(particle["y"])
        if particle["kind"] == "Étoiles":
            points = [(px, py-radius-2), (px+2, py-1), (px+radius+2, py),
                      (px+2, py+1), (px, py+radius+2), (px-2, py+1),
                      (px-radius-2, py), (px-2, py-1)]
            pygame.draw.polygon(screen, particle["color"], points)
        elif particle["kind"] == "Flammes":
            pygame.draw.ellipse(screen, particle["color"], (px-radius, py-radius, radius*2, radius*3))
        else:
            pygame.draw.circle(screen, particle["color"], (px, py), radius)
    if mode == "3d":
        pygame.draw.circle(screen, (140, 155, 220), (105, int(game["bird_y"])), 25, 2)
    draw_bird(105, game["bird_y"], bird_color(save_data["bird"]))
    draw_text_center(f"{game['score']}", 42, FONT)
    draw_text_center(f"Pièces : {'∞' if dev_mode_enabled() else format(save_data['coins'], ',').replace(',', ' ')}", 77, SMALL, GOLD)
    if mode == "3d":
        draw_text_center("MODE 3D · +2 pièces par tuyau", 105, TINY, (230, 230, 255))
    if game["x2_remaining"] > 0 and not game["over"]:
        draw_text_center(f"BONUS x2 : {game['x2_remaining']} tuyaux", 130, SMALL, GOLD)
    if save_data["magnet"] and not game["over"]:
        draw_text_center("AIMANT ACTIF", HEIGHT - 78, TINY, (255, 235, 100))

    if not game["started"] and not game["over"]:
        pygame.draw.rect(screen, (25, 30, 45), (55, 260, WIDTH - 110, 100), border_radius=12)
        draw_text_center("PRÊT ?", 288, MEDIUM)
        draw_text_center("ESPACE ou clic pour décoller", 325, SMALL)
    if game["revive_countdown"] > 0:
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 145))
        screen.blit(overlay, (0, 0))
        seconds_left = max(1, (game["revive_countdown"] + 59) // 60)
        draw_text_center("SAUVETAGE", 285, FONT, GOLD)
        draw_text_center(str(seconds_left), 355, pygame.font.SysFont("Arial", 64, bold=True), WHITE)
        draw_text_center("Tu repars de la même position !", 415, MEDIUM, WHITE)
    if game["over"]:
        pygame.draw.rect(screen, (255, 255, 255), (35, 198, WIDTH - 70, 270), border_radius=17)
        draw_text_center("GAME OVER", 235, FONT, BLACK)
        draw_text_center(f"Score : {game['score']}", 276, MEDIUM, BLACK)
        draw_text_center("Score sauvegardé · +3 pièces", 309, SMALL, BLACK)
        if game["mode"] == "3d":
            draw_text_center("Bonus mode 3D : 2 pièces/tuyau", 337, TINY, BLACK)
        draw_text_center(f"Meilleur score : {save_data['stats']['best_run']}", 359, SMALL, BLACK)
        draw_button(pygame.Rect(55, 400, 190, 43), "REJOUER", small=True)
        draw_button(pygame.Rect(275, 400, 190, 43), "MENU", small=True)
        if game["revive_used"]:
            draw_text_center("Jeton de sauvetage utilisé", 455, TINY, BLACK)
        else:
            draw_text_center(f"Jetons en stock : {save_data['revives']}", 455, TINY, BLACK)


def handle_pipe_pass(pipe):
    pipe["scored"] = True
    game["score"] += 1
    game["pipes_passed"] += 1
    save_data["stats"]["pipes"] += 1
    base_coins = 2 if game["mode"] == "3d" else COINS_PER_PIPE
    payout = base_coins * (2 if game["x2_remaining"] > 0 else 1)
    award_coins(payout)
    if game["x2_remaining"] > 0:
        game["x2_remaining"] -= 1
    if game["pipes_passed"] % 2 == 0 and random.randint(1, 3) == 1:
        # La bulle est attachée au prochain tuyau et reste dans son ouverture.
        next_pipes = [p for p in game["pipes"] if p is not pipe and p["x"] > pipe["x"]]
        if next_pipes:
            next_pipe = min(next_pipes, key=lambda p: p["x"])
            pickup_x = next_pipe["x"] + 37
            pickup_y = random.randint(next_pipe["gap_y"] + 35, next_pipe["gap_y"] + 140)
            game["pickups"].append({
                "type": "x2", "x": pickup_x, "y": pickup_y,
                "collected": False, "attached_pipe": next_pipe,
            })
    if game["pipes_passed"] % 4 == 0:
        # La pièce est liée à un tuyau précis et reste dans son ouverture.
        next_pipes = [p for p in game["pipes"] if p is not pipe and p["x"] > pipe["x"]]
        if next_pipes:
            next_pipe = min(next_pipes, key=lambda p: p["x"])
            pickup_x = next_pipe["x"] + 37
            # Le rectangle de collecte reste entièrement dans l'ouverture de 175 px.
            pickup_y = random.randint(next_pipe["gap_y"] + 42, next_pipe["gap_y"] + 133)
            game["pickups"].append({
                "type": "coin", "x": pickup_x, "y": pickup_y,
                "collected": False, "attached_pipe": next_pipe,
            })
    save_game()


def set_rgb_channel(channel, value):
    """Met à jour un canal RGB et resynchronise la position du sélecteur HSV."""
    rgb = list(save_data.get("custom_bird_rgb", [255, 80, 190]))
    rgb[channel] = max(0, min(255, int(value)))
    save_data["custom_bird_rgb"] = rgb
    save_data["custom_bird_hsv"] = list(colorsys.rgb_to_hsv(*(v / 255.0 for v in rgb)))
    save_game()


def update_custom_color_from_pointer(pos, mode):
    """Actualise continuellement la roue ou la luminosité pendant un glissement."""
    px, py = pos
    hsv = list(save_data.get("custom_bird_hsv", [0.91, 0.69, 1.0]))
    if mode == "wheel":
        dx, dy = px - WIDTH // 2, py - 475
        distance = (dx * dx + dy * dy) ** 0.5
        if distance > 70:
            dx *= 70 / distance
            dy *= 70 / distance
            distance = 70
        hsv[0] = (math.atan2(dy, dx) / (2 * math.pi)) % 1.0
        hsv[1] = max(0.0, min(1.0, distance / 69.0))
    elif mode == "brightness":
        hsv[2] = max(0.0, min(1.0, (px - 155) / 209.0))
    save_data["custom_bird_hsv"] = hsv
    update_custom_bird_color_from_hsv()
    save_game()


def click_menu(pos):
    global menu_page, shop_tab, custom_tab, custom_env_mode
    rects = main_button_rects()
    if menu_page == "main":
        if rects["play"].collidepoint(pos):
            start_game("classic")
        elif rects["mode3d"].collidepoint(pos):
            if "3d" not in save_data["unlocked_modes"]:
                buy_mode_3d()
            else:
                start_game("3d")
        elif rects["shop"].collidepoint(pos):
            menu_page = "shop"
            shop_tab = "rotation"
            ensure_shop_rotation()
        elif rects["custom"].collidepoint(pos):
            menu_page = "custom"
        elif rects["daily"].collidepoint(pos):
            menu_page = "daily"
        elif rects["missions"].collidepoint(pos):
            menu_page = "missions"
        elif rects["ranking"].collidepoint(pos):
            menu_page = "ranking"
        elif rects["stats"].collidepoint(pos):
            menu_page = "stats"
        return

    if menu_page == "shop":
        if pygame.Rect(20, 145, 230, 36).collidepoint(pos):
            shop_tab = "rotation"
            return
        if pygame.Rect(270, 145, 230, 36).collidepoint(pos):
            shop_tab = "upgrades"
            return
        if pygame.Rect(145, 580, 230, 42).collidepoint(pos):
            menu_page = "main"
            return
        if shop_tab == "rotation":
            if pygame.Rect(25, 445, WIDTH-50, 43).collidepoint(pos):
                if "Custom" in save_data["unlocked_birds"]:
                    set_notice("Couleur RGB déjà débloquée : va dans SKINS > OISEAU > Custom.")
                elif can_afford(100):
                    spend_coins(100)
                    save_data["unlocked_birds"].append("Custom")
                    save_data["bird"] = "Custom"
                    save_game()
                    set_notice("Couleur RGB débloquée et équipée ! Personnalise-la dans SKINS.", 250)
                else:
                    set_notice("Il te faut 100 pièces pour débloquer la couleur RGB.")
                return
            if dev_mode_enabled() and pygame.Rect(70, 500, 380, 36).collidepoint(pos):
                refresh_shop_dev()
                return
            offers = ensure_shop_rotation()
            for i, item in enumerate(offers[:SHOP_OFFER_COUNT]):
                if pygame.Rect(25, 190 + i * 50, WIDTH - 50, 43).collidepoint(pos):
                    buy_rotating_cosmetic(item)
                    return
        else:
            for i, item in enumerate(shop_items()):
                if pygame.Rect(35, 190 + i * 49, WIDTH - 70, 42).collidepoint(pos):
                    click_shop_item(item)
                    return
    elif menu_page == "custom":
        if pygame.Rect(145, 620, 230, 38).collidepoint(pos):
            menu_page = "main"
        elif pygame.Rect(25, 112, 225, 42).collidepoint(pos):
            custom_tab = "bird"
        elif pygame.Rect(270, 112, 225, 42).collidepoint(pos):
            custom_tab = "environment"
        else:
            if custom_tab == "bird" and save_data.get("bird") == "Custom":
                global rgb_edit_channel, rgb_edit_buffer, color_drag_mode
                px, py = pos
                rgb_boxes = [(pygame.Rect(x - 35, 578, 70, 29), channel)
                             for channel, x in ((0, 105), (1, 220), (2, 335))]
                clicked_rgb = False
                for box, channel in rgb_boxes:
                    if box.collidepoint(pos):
                        rgb_edit_channel = channel
                        rgb_edit_buffer = ""
                        clicked_rgb = True
                        color_drag_mode = None
                        break
                if not clicked_rgb:
                    rgb_edit_channel = None
                    rgb_edit_buffer = ""
                    dx, dy = px - WIDTH // 2, py - 475
                    distance = (dx * dx + dy * dy) ** 0.5
                    if distance <= 74:
                        color_drag_mode = "wheel"
                        update_custom_color_from_pointer(pos, color_drag_mode)
                    elif 145 <= px <= 375 and 548 <= py <= 574:
                        color_drag_mode = "brightness"
                        update_custom_color_from_pointer(pos, color_drag_mode)
                    else:
                        color_drag_mode = None
                        custom_row_at(pos)
            else:
                custom_row_at(pos)
    elif menu_page == "daily":
        if pygame.Rect(110, 450, 300, 48).collidepoint(pos):
            claim_daily_reward()
        elif pygame.Rect(145, 515, 230, 43).collidepoint(pos):
            menu_page = "main"
    elif menu_page == "missions":
        if pygame.Rect(145, 585, 230, 43).collidepoint(pos):
            menu_page = "main"
            return
        for i, mission in enumerate(MISSIONS):
            y = 180 + i * 64
            claim_rect = pygame.Rect(370, y + 11, 125, 34)
            if claim_rect.collidepoint(pos):
                if mission["id"] not in save_data["claimed_missions"] and save_data["stats"].get(mission["stat"], 0) >= mission["target"]:
                    claim_mission(mission)
                else:
                    set_notice("Mission pas encore terminée ou déjà réclamée.")
                return
    elif menu_page == "ranking":
        if pygame.Rect(145, 575, 230, 43).collidepoint(pos):
            menu_page = "main"
    elif menu_page == "stats":
        if pygame.Rect(145, 555, 230, 43).collidepoint(pos):
            menu_page = "main"


def handle_pointer_down(pos):
    """Gère un appui souris ou tactile avec les coordonnées du jeu."""
    global scene, menu_page
    if scene == "menu":
        click_menu(pos)
    elif scene == "game":
        if game["over"]:
            if pygame.Rect(55, 400, 190, 43).collidepoint(pos):
                start_game(game["mode"])
                game["started"] = True
                game["velocity"] = -7.5
            elif pygame.Rect(275, 400, 190, 43).collidepoint(pos):
                scene = "menu"
                menu_page = "main"
            else:
                start_game(game["mode"])
                game["started"] = True
                game["velocity"] = -7.5
        else:
            game["started"] = True
            game["velocity"] = -7.5


async def main():
    global scene, menu_page, notice_timer, color_drag_mode, rgb_edit_channel, rgb_edit_buffer, last_finger_event_time
    # Boucle principale
    last_finger_event_time = 0.0
    running = True
    while running:
        clock.tick(60)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                save_game()
                running = False
                break

            # Sur mobile, les événements FINGER utilisent des coordonnées normalisées (0..1).
            # Ils sont convertis dans la résolution logique 520x700 du jeu.
            if event.type == pygame.FINGERDOWN:
                last_finger_event_time = time.time()
                pos = (int(event.x * WIDTH), int(event.y * HEIGHT))
                if scene == "menu" and menu_page == "custom" and custom_tab == "bird" and save_data.get("bird") == "Custom":
                    if pygame.Rect(WIDTH // 2 - 72, 405, 144, 140).collidepoint(pos):
                        color_drag_mode = "wheel"
                        update_custom_color_from_pointer(pos, color_drag_mode)
                    elif pygame.Rect(145, 565, 220, 34).collidepoint(pos):
                        color_drag_mode = "brightness"
                        update_custom_color_from_pointer(pos, color_drag_mode)
                handle_pointer_down(pos)

            if event.type == pygame.FINGERMOTION:
                pos = (int(event.x * WIDTH), int(event.y * HEIGHT))
                if scene == "menu" and menu_page == "custom" and custom_tab == "bird" and save_data.get("bird") == "Custom" and color_drag_mode:
                    update_custom_color_from_pointer(pos, color_drag_mode)

            if event.type == pygame.FINGERUP:
                color_drag_mode = None

            if event.type == pygame.MOUSEMOTION and event.buttons[0]:
                if scene == "menu" and menu_page == "custom" and custom_tab == "bird" and save_data.get("bird") == "Custom" and color_drag_mode:
                    update_custom_color_from_pointer(event.pos, color_drag_mode)

            if event.type == pygame.KEYDOWN:
                if scene == "menu" and menu_page == "custom" and custom_tab == "bird" and save_data.get("bird") == "Custom" and rgb_edit_channel is not None:
                    if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                        if rgb_edit_buffer.strip().isdigit():
                            set_rgb_channel(rgb_edit_channel, int(rgb_edit_buffer))
                        rgb_edit_channel = None
                        rgb_edit_buffer = ""
                    elif event.key == pygame.K_BACKSPACE:
                        rgb_edit_buffer = rgb_edit_buffer[:-1]
                    elif event.unicode.isdigit() and len(rgb_edit_buffer) < 3:
                        rgb_edit_buffer += event.unicode
                    elif event.key == pygame.K_ESCAPE:
                        rgb_edit_channel = None
                        rgb_edit_buffer = ""
                    continue
                # Code secret saisi uniquement avec le pavé numérique : 1-2-3-4.
                if event.key in DEV_KEY_SEQUENCE and not dev_mode_enabled():
                    dev_key_buffer.append(event.key)
                    dev_key_buffer[:] = dev_key_buffer[-4:]
                    if dev_key_buffer == DEV_KEY_SEQUENCE:
                        dev_key_buffer.clear()
                        unlock_developer_mode()
                elif event.key not in DEV_KEY_SEQUENCE:
                    dev_key_buffer.clear()

                if event.key == pygame.K_ESCAPE:
                    if scene == "game":
                        scene = "menu"
                        menu_page = "main"
                    elif menu_page != "main":
                        menu_page = "main"
                    else:
                        save_game()
                        running = False

                if scene == "menu":
                    if menu_page == "main" and event.key == pygame.K_RETURN:
                        start_game("classic")
                    elif menu_page == "custom":
                        if event.key in (pygame.K_LEFT, pygame.K_RIGHT):
                            direction = -1 if event.key == pygame.K_LEFT else 1
                            save_data["bird"] = cycle_unlocked("unlocked_birds", BIRDS, save_data["bird"], direction)
                            save_game()
                        elif event.key in (pygame.K_a, pygame.K_d):
                            direction = -1 if event.key == pygame.K_a else 1
                            save_data["pipe"] = cycle_unlocked("unlocked_pipes", PIPES, save_data["pipe"], direction)
                            save_game()
                        elif event.key in (pygame.K_w, pygame.K_s):
                            direction = -1 if event.key == pygame.K_w else 1
                            save_data["background"] = cycle_unlocked("unlocked_backgrounds", BACKGROUNDS, save_data["background"], direction)
                            save_game()
                    elif menu_page in ("shop", "daily", "missions", "ranking", "stats", "custom") and event.key == pygame.K_BACKSPACE:
                        menu_page = "main"
                elif scene == "game":
                    if event.key in (pygame.K_SPACE, pygame.K_UP):
                        if game["over"]:
                            start_game(game["mode"])
                            game["started"] = True
                            game["velocity"] = -7.5
                        else:
                            game["started"] = True
                            game["velocity"] = -7.5

            if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                color_drag_mode = None

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                # Certains navigateurs transforment un toucher en FINGERDOWN + clic souris.
                # On ignore le clic souris doublon, sans affecter la souris d'un ordinateur.
                if time.time() - last_finger_event_time < 0.30:
                    continue
                handle_pointer_down(event.pos)

        if not running:
            break

        if scene == "game":
            if game["revive_countdown"] > 0:
                game["revive_countdown"] -= 1
                if game["revive_countdown"] == 0:
                    game["bird_y"] = game["revive_y"]
                    game["velocity"] = -5.0
                    game["pipes"] = [p for p in game["pipes"]
                                     if not (p["x"] < 180 and p["x"] + 75 > 30)]
                    game["revive_invuln"] = 90
                    game["particles"].clear()
                    set_notice("Sauvetage terminé !", 100)

            if game["started"] and not game["over"] and game["revive_countdown"] == 0:
                if game["revive_invuln"] > 0:
                    game["revive_invuln"] -= 1
                game["velocity"] += 0.42
                game["bird_y"] += game["velocity"]
                update_trail_particles()

                if not game["pipes"] or game["pipes"][-1]["x"] < WIDTH - 240:
                    game["pipes"].append({
                        "x": WIDTH,
                        "gap_y": random.randint(170, HEIGHT - 230),
                        "scored": False,
                    })

                hit = False
                for pipe in game["pipes"]:
                    pipe["x"] -= 3
                    if game["revive_invuln"] <= 0 and collides_with_pipe(pipe):
                        hit = True
                        break
                    if not pipe["scored"] and pipe["x"] + 75 < 105:
                        handle_pipe_pass(pipe)
                if hit:
                    handle_crash()

                game["pipes"] = [p for p in game["pipes"] if p["x"] + 90 > 0]
                if not game["over"] and (game["bird_y"] + 17 >= HEIGHT - 55 or game["bird_y"] - 17 <= 0):
                    handle_crash()

                if not game["over"]:
                    buy_or_collect_pickups()
            draw_game()
        else:
            draw_menu()

        if notice_timer > 0:
            notice_timer -= 1
        pygame.display.flip()
        await asyncio.sleep(0)

asyncio.run(main())
