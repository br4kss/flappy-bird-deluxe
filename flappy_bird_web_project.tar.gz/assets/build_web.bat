@echo off
python -m pip install --upgrade pygbag
python -m pygbag --build .
if errorlevel 1 exit /b %errorlevel%
python apply_pwa.py
echo.
echo Terminé. Publie le contenu de build\web sur un hébergement HTTPS.
pause
