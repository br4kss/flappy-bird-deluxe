@echo off
setlocal
cd /d "%~dp0"
title Construire Flappy Bird - responsive

echo.
echo === 1/2 : Construction Pygbag depuis main.py ===
python -m pygbag --build .
if errorlevel 1 (
  echo.
  echo ERREUR pendant la construction Pygbag.
  pause
  exit /b 1
)

echo.
echo === 2/2 : Adaptation responsive du canevas ===
python apply_responsive.py
if errorlevel 1 (
  echo.
  echo ERREUR pendant l'adaptation responsive.
  pause
  exit /b 1
)

echo.
echo Terminé. Le dossier build\web contient maintenant la version web responsive.
echo Le format du jeu reste portrait (ratio 520 x 700) et s'adapte aux ecrans.
pause
