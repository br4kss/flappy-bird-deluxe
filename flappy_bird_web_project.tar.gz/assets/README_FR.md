# Flappy Bird Deluxe Ultimate — version web pour iPhone

Ce projet contient le jeu Python et les fichiers pour préparer une version navigateur avec Pygbag, puis l'ajouter à l'écran d'accueil d'un iPhone.

## 1. Construire le jeu web sur Windows

Installe Python 3.11 ou 3.12 si possible, puis ouvre un terminal dans ce dossier :

```powershell
python -m pip install --upgrade pygbag
python -m pygbag --build .
```

Pygbag doit générer le site dans `build/web/`.

## 2. Ajouter les fichiers PWA

Une fois la compilation terminée, exécute :

```powershell
python apply_pwa.py
```

Cela copie le manifeste, l'icône et le service worker dans `build/web/` et ajoute les références nécessaires à la page générée.

## 3. Tester sur le PC (ne pas ouvrir index.html directement)

**Important : ne double-clique pas sur `build/web/index.html`.** Le navigateur bloque certains chargements nécessaires au jeu lorsqu'il est ouvert avec une adresse `file://`, ce qui peut laisser « Pygame loading, please wait… » tourner sans fin.

Après une compilation réussie, double-clique sur `run_local.bat`. Il démarre un serveur local et ouvre `http://127.0.0.1:8000/`. Garde la fenêtre noire ouverte pendant le test.

Si le chargement reste bloqué, essaie de construire avec Python 3.11 ou 3.12 (Python 3.15 peut ne pas être pris en charge par tous les outils de Pygbag), puis relance `build_web.bat`. Regarde aussi les erreurs dans le terminal et dans le navigateur avec `F12` → `Console`.

## 4. Publier le site en HTTPS

Il faut héberger **le contenu du dossier `build/web/`**, pas seulement `main.py`, sur un hébergeur de sites statiques HTTPS (par exemple Netlify Drop ou GitHub Pages). Le navigateur doit pouvoir charger les fichiers WASM/jeu depuis le même site.

Le projet n'est pas publié automatiquement par ce ZIP : l'hébergement est nécessaire pour obtenir ton propre lien Safari.

## 5. Installer sur iPhone 17 Pro Max

1. Ouvre le lien HTTPS dans Safari.
2. Appuie sur **Partager**.
3. Choisis **Sur l'écran d'accueil**.
4. Valide avec **Ajouter**.

Le jeu s'ouvrira alors depuis une icône. La sauvegarde tente d'utiliser le stockage local du navigateur pour conserver la progression sur le même appareil et dans le même navigateur.

## Remarques

- Le jeu garde une résolution logique portrait de 520 × 700, mise à l'échelle par le lecteur web.
- Les commandes tactiles et le glissement RGB sont gérés dans le code du jeu.
- La construction Pygbag doit être faite avec une connexion Internet afin que ses outils puissent télécharger les composants nécessaires.
- Après chaque nouvelle version du jeu, reconstruis et republie `build/web/`. Le service worker peut garder temporairement des fichiers en cache ; si tu vois une ancienne version, recharge le site ou efface les données du site dans Safari.
