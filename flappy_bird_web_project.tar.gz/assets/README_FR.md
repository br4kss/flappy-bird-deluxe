# Flappy Bird Deluxe Ultimate — mise à jour responsive

Cette version garde la résolution logique portrait du jeu (520 × 700) et ajuste le canevas pour l'écran disponible sur téléphone, tablette et ordinateur, sans étirer l'image.

## Mise à jour
1. Copie ton `main.py` actuel dans ce dossier si tu as fait des modifications récentes.
2. Lance `build_web.bat`.
3. Publie le contenu de `build/web/` à la racine de ton dépôt GitHub Pages.
4. Sur iPhone, ferme puis rouvre le jeu. Si l'ancienne version apparaît encore, recharge Safari et vérifie le cache/service worker.

Le script `apply_pwa.py` ajoute la mise en page responsive après chaque compilation Pygbag.
